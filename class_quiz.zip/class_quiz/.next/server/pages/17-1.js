"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/17-1";
exports.ids = ["pages/17-1"];
exports.modules = {

/***/ "./pages/17-1/index.tsx":
/*!******************************!*\
  !*** ./pages/17-1/index.tsx ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ IsChangedPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction IsChangedPage() {\n    const { 0: isChanged , 1: setIsChanged  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    const onClickChangedBtn = ()=>{\n        // alert(\"Changed!!\");\n        setIsChanged(true);\n    };\n    const onClickMovedBtn = ()=>{\n        router.push(\"/\");\n    };\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        alert(\"Rendered!\");\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        alert(\"Changed!!\");\n    }, [\n        isChanged\n    ]);\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        return ()=>{\n            alert(\"Bye!!\");\n        };\n    }, []);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickChangedBtn,\n                children: \"변경\"\n            }, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-1/index.tsx\",\n                lineNumber: 33,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickMovedBtn,\n                children: \"이동\"\n            }, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-1/index.tsx\",\n                lineNumber: 34,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-1/index.tsx\",\n        lineNumber: 32,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNy0xL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUF1QztBQUNJO0FBRTVCLFFBQVEsQ0FBQ0csYUFBYSxHQUFHLENBQUM7SUFDdkMsS0FBSyxNQUFFQyxTQUFTLE1BQUVDLFlBQVksTUFBSUgsK0NBQVEsQ0FBQyxLQUFLO0lBQ2hELEtBQUssQ0FBQ0ksTUFBTSxHQUFHTixzREFBUztJQUV4QixLQUFLLENBQUNPLGlCQUFpQixPQUFTLENBQUM7UUFDL0IsRUFBc0I7UUFDdEJGLFlBQVksQ0FBQyxJQUFJO0lBQ25CLENBQUM7SUFFRCxLQUFLLENBQUNHLGVBQWUsT0FBUyxDQUFDO1FBQzdCRixNQUFNLENBQUNHLElBQUksQ0FBQyxDQUFHO0lBQ2pCLENBQUM7SUFFRFIsZ0RBQVMsS0FBTyxDQUFDO1FBQ2ZTLEtBQUssQ0FBQyxDQUFXO0lBQ25CLENBQUMsRUFBRSxDQUFDLENBQUM7SUFFTFQsZ0RBQVMsS0FBTyxDQUFDO1FBQ2ZTLEtBQUssQ0FBQyxDQUFXO0lBQ25CLENBQUMsRUFBRSxDQUFDTjtRQUFBQSxTQUFTO0lBQUEsQ0FBQztJQUVkSCxnREFBUyxLQUFPLENBQUM7UUFDZixNQUFNLEtBQU8sQ0FBQztZQUNaUyxLQUFLLENBQUMsQ0FBTztRQUNmLENBQUM7SUFDSCxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBRUwsTUFBTSw2RUFDSEMsQ0FBRzs7d0ZBQ0RDLENBQU07Z0JBQUNDLE9BQU8sRUFBRU4saUJBQWlCOzBCQUFFLENBQUU7Ozs7Ozt3RkFDakNLLENBQUU7Z0JBQUNDLE9BQU8sRUFBRUwsZUFBZTswQkFBRSxDQUFFOzs7Ozs7Ozs7Ozs7QUFHMUMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9wYWdlcy8xNy0xL2luZGV4LnRzeD8yZTg1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBJc0NoYW5nZWRQYWdlKCkge1xuICBjb25zdCBbaXNDaGFuZ2VkLCBzZXRJc0NoYW5nZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblxuICBjb25zdCBvbkNsaWNrQ2hhbmdlZEJ0biA9ICgpID0+IHtcbiAgICAvLyBhbGVydChcIkNoYW5nZWQhIVwiKTtcbiAgICBzZXRJc0NoYW5nZWQodHJ1ZSk7XG4gIH07XG5cbiAgY29uc3Qgb25DbGlja01vdmVkQnRuID0gKCkgPT4ge1xuICAgIHJvdXRlci5wdXNoKFwiL1wiKTtcbiAgfTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGFsZXJ0KFwiUmVuZGVyZWQhXCIpO1xuICB9LCBbXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBhbGVydChcIkNoYW5nZWQhIVwiKTtcbiAgfSwgW2lzQ2hhbmdlZF0pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGFsZXJ0KFwiQnllISFcIik7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja0NoYW5nZWRCdG59PuuzgOqyvTwvYnV0dG9uPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrTW92ZWRCdG59PuydtOuPmTwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl0sIm5hbWVzIjpbInVzZVJvdXRlciIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiSXNDaGFuZ2VkUGFnZSIsImlzQ2hhbmdlZCIsInNldElzQ2hhbmdlZCIsInJvdXRlciIsIm9uQ2xpY2tDaGFuZ2VkQnRuIiwib25DbGlja01vdmVkQnRuIiwicHVzaCIsImFsZXJ0IiwiZGl2IiwiYnV0dG9uIiwib25DbGljayJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/17-1/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/17-1/index.tsx"));
module.exports = __webpack_exports__;

})();