"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/17-3";
exports.ids = ["pages/17-3"];
exports.modules = {

/***/ "./pages/17-3/index.tsx":
/*!******************************!*\
  !*** ./pages/17-3/index.tsx ***!
  \******************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ OpenDogAPI)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);\naxios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction OpenDogAPI() {\n    const { 0: dog , 1: setDog  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    const OpenDogAPIFunc = async ()=>{\n        const result = await axios__WEBPACK_IMPORTED_MODULE_1__[\"default\"].get(\"https://dog.ceo/api/breeds/image/random\");\n        console.log(result.data.message);\n    // setDog(result.data.message);\n    };\n    OpenDogAPIFunc();\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n            src: dog\n        }, void 0, false, {\n            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-3/index.tsx\",\n            lineNumber: 17,\n            columnNumber: 7\n        }, this)\n    }, void 0, false));\n};\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNy0zL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQXlCO0FBQ087QUFFakIsUUFBUSxDQUFDRSxVQUFVLEdBQUcsQ0FBQztJQUNwQyxLQUFLLE1BQUVDLEdBQUcsTUFBRUMsTUFBTSxNQUFJSCwrQ0FBUSxDQUFDLENBQUU7SUFFakMsS0FBSyxDQUFDSSxjQUFjLGFBQWUsQ0FBQztRQUNsQyxLQUFLLENBQUNDLE1BQU0sR0FBRyxLQUFLLENBQUNOLGlEQUFTLENBQUMsQ0FBeUM7UUFDeEVRLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDSCxNQUFNLENBQUNJLElBQUksQ0FBQ0MsT0FBTztJQUMvQixFQUErQjtJQUNqQyxDQUFDO0lBRUROLGNBQWM7SUFFZCxNQUFNOzhGQUVETyxDQUFHO1lBQUNDLEdBQUcsRUFBRVYsR0FBRzs7Ozs7OztBQUduQixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3BhZ2VzLzE3LTMvaW5kZXgudHN4PzVkMGYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9zIGZyb20gXCJheGlvc1wiO1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gT3BlbkRvZ0FQSSgpIHtcbiAgY29uc3QgW2RvZywgc2V0RG9nXSA9IHVzZVN0YXRlKFwiXCIpO1xuXG4gIGNvbnN0IE9wZW5Eb2dBUElGdW5jID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGF4aW9zLmdldChcImh0dHBzOi8vZG9nLmNlby9hcGkvYnJlZWRzL2ltYWdlL3JhbmRvbVwiKTtcbiAgICBjb25zb2xlLmxvZyhyZXN1bHQuZGF0YS5tZXNzYWdlKTtcbiAgICAvLyBzZXREb2cocmVzdWx0LmRhdGEubWVzc2FnZSk7XG4gIH07XG5cbiAgT3BlbkRvZ0FQSUZ1bmMoKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8aW1nIHNyYz17ZG9nfSAvPlxuICAgIDwvPlxuICApO1xufVxuIl0sIm5hbWVzIjpbImF4aW9zIiwidXNlU3RhdGUiLCJPcGVuRG9nQVBJIiwiZG9nIiwic2V0RG9nIiwiT3BlbkRvZ0FQSUZ1bmMiLCJyZXN1bHQiLCJnZXQiLCJjb25zb2xlIiwibG9nIiwiZGF0YSIsIm1lc3NhZ2UiLCJpbWciLCJzcmMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/17-3/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/17-3/index.tsx"));
module.exports = __webpack_exports__;

})();