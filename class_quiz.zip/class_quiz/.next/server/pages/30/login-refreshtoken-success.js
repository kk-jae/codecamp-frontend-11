"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/30/login-refreshtoken-success";
exports.ids = ["pages/30/login-refreshtoken-success"];
exports.modules = {

/***/ "./pages/30/login-refreshtoken-success/index.tsx":
/*!*******************************************************!*\
  !*** ./pages/30/login-refreshtoken-success/index.tsx ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _src_commons_library_asyncFunc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../src/commons/library/asyncFunc */ \"./src/commons/library/asyncFunc.ts\");\n\n\n\nconst FETCH_USER_LOGGED_IN = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  query {\n    fetchUserLoggedIn {\n      email\n      name\n      _id\n    }\n  }\n`;\nfunction LoginPage() {\n    const client = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useApolloClient)();\n    const onClickButton = async ()=>{\n        const result = await client.query({\n            query: FETCH_USER_LOGGED_IN\n        });\n        console.log(result);\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n            onClick: (0,_src_commons_library_asyncFunc__WEBPACK_IMPORTED_MODULE_2__.wrapAsync)(onClickButton),\n            children: \"클릭하세요\"\n        }, void 0, false, {\n            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/30/login-refreshtoken-success/index.tsx\",\n            lineNumber: 26,\n            columnNumber: 7\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8zMC9sb2dpbi1yZWZyZXNodG9rZW4tc3VjY2Vzcy9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFxRDtBQUNhO0FBRWxFLEtBQUssQ0FBQ0csb0JBQW9CLEdBQUdILCtDQUFHLENBQUM7Ozs7Ozs7O0FBUWpDO0FBRWUsUUFBUSxDQUFDSSxTQUFTLEdBQWdCLENBQUM7SUFDaEQsS0FBSyxDQUFDQyxNQUFNLEdBQUdKLCtEQUFlO0lBRTlCLEtBQUssQ0FBQ0ssYUFBYSxhQUE4QixDQUFDO1FBQ2hELEtBQUssQ0FBQ0MsTUFBTSxHQUFHLEtBQUssQ0FBQ0YsTUFBTSxDQUFDRyxLQUFLLENBQUMsQ0FBQztZQUNqQ0EsS0FBSyxFQUFFTCxvQkFBb0I7UUFDN0IsQ0FBQztRQUNETSxPQUFPLENBQUNDLEdBQUcsQ0FBQ0gsTUFBTTtJQUNwQixDQUFDO0lBRUQsTUFBTTs4RkFFREksQ0FBTTtZQUFDQyxPQUFPLEVBQUVWLHlFQUFTLENBQUNJLGFBQWE7c0JBQUcsQ0FBSzs7Ozs7OztBQUd0RCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY29kZWNhbXAvLi9wYWdlcy8zMC9sb2dpbi1yZWZyZXNodG9rZW4tc3VjY2Vzcy9pbmRleC50c3g/ZTNlMCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBncWwsIHVzZUFwb2xsb0NsaWVudCB9IGZyb20gXCJAYXBvbGxvL2NsaWVudFwiO1xuaW1wb3J0IHsgd3JhcEFzeW5jIH0gZnJvbSBcIi4uLy4uLy4uL3NyYy9jb21tb25zL2xpYnJhcnkvYXN5bmNGdW5jXCI7XG5cbmNvbnN0IEZFVENIX1VTRVJfTE9HR0VEX0lOID0gZ3FsYFxuICBxdWVyeSB7XG4gICAgZmV0Y2hVc2VyTG9nZ2VkSW4ge1xuICAgICAgZW1haWxcbiAgICAgIG5hbWVcbiAgICAgIF9pZFxuICAgIH1cbiAgfVxuYDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTG9naW5QYWdlKCk6IEpTWC5FbGVtZW50IHtcbiAgY29uc3QgY2xpZW50ID0gdXNlQXBvbGxvQ2xpZW50KCk7XG5cbiAgY29uc3Qgb25DbGlja0J1dHRvbiA9IGFzeW5jICgpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjbGllbnQucXVlcnkoe1xuICAgICAgcXVlcnk6IEZFVENIX1VTRVJfTE9HR0VEX0lOLFxuICAgIH0pO1xuICAgIGNvbnNvbGUubG9nKHJlc3VsdCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXt3cmFwQXN5bmMob25DbGlja0J1dHRvbil9Pu2BtOumre2VmOyEuOyalDwvYnV0dG9uPlxuICAgIDwvPlxuICApO1xufVxuIl0sIm5hbWVzIjpbImdxbCIsInVzZUFwb2xsb0NsaWVudCIsIndyYXBBc3luYyIsIkZFVENIX1VTRVJfTE9HR0VEX0lOIiwiTG9naW5QYWdlIiwiY2xpZW50Iiwib25DbGlja0J1dHRvbiIsInJlc3VsdCIsInF1ZXJ5IiwiY29uc29sZSIsImxvZyIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/30/login-refreshtoken-success/index.tsx\n");

/***/ }),

/***/ "./src/commons/library/asyncFunc.ts":
/*!******************************************!*\
  !*** ./src/commons/library/asyncFunc.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"wrapAsync\": () => (/* binding */ wrapAsync),\n/* harmony export */   \"wrapFormAsync\": () => (/* binding */ wrapFormAsync)\n/* harmony export */ });\nconst wrapAsync = (asyncFunc)=>()=>{\n        void asyncFunc();\n    }\n;\nconst wrapFormAsync = (asyncFunc)=>{\n    return (event)=>{\n        event === null || event === void 0 ? void 0 : event.preventDefault();\n        void asyncFunc();\n    };\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9saWJyYXJ5L2FzeW5jRnVuYy50cy5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUVPLEtBQUssQ0FBQ0EsU0FBUyxJQUFJQyxTQUE4QixPQUFXLENBQUM7UUFDbEUsSUFBSSxDQUFDQSxTQUFTO0lBQ2hCLENBQUM7O0FBRU0sS0FBSyxDQUFDQyxhQUFhLElBQ3ZCRCxTQUE4QjtJQUFLLE1BQU0sRUFBTEUsS0FBaUMsR0FBSyxDQUFDO1FBQzFFQSxLQUFLLGFBQUxBLEtBQUssS0FBTEEsSUFBSSxDQUFKQSxDQUFxQixHQUFyQkEsSUFBSSxDQUFKQSxDQUFxQixHQUFyQkEsS0FBSyxDQUFFQyxjQUFjO1FBQ3JCLElBQUksQ0FBQ0gsU0FBUztJQUNoQixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY29kZWNhbXAvLi9zcmMvY29tbW9ucy9saWJyYXJ5L2FzeW5jRnVuYy50cz9kZjI3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgRm9ybUV2ZW50IH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBjb25zdCB3cmFwQXN5bmMgPSAoYXN5bmNGdW5jOiAoKSA9PiBQcm9taXNlPHZvaWQ+KSA9PiAoKSA9PiB7XG4gIHZvaWQgYXN5bmNGdW5jKCk7XG59O1xuXG5leHBvcnQgY29uc3Qgd3JhcEZvcm1Bc3luYyA9XG4gIChhc3luY0Z1bmM6ICgpID0+IFByb21pc2U8dm9pZD4pID0+IChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pID0+IHtcbiAgICBldmVudD8ucHJldmVudERlZmF1bHQoKTtcbiAgICB2b2lkIGFzeW5jRnVuYygpO1xuICB9O1xuIl0sIm5hbWVzIjpbIndyYXBBc3luYyIsImFzeW5jRnVuYyIsIndyYXBGb3JtQXN5bmMiLCJldmVudCIsInByZXZlbnREZWZhdWx0Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/commons/library/asyncFunc.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/30/login-refreshtoken-success/index.tsx"));
module.exports = __webpack_exports__;

})();