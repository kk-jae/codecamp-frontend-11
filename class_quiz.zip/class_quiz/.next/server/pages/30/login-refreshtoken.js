"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/30/login-refreshtoken";
exports.ids = ["pages/30/login-refreshtoken"];
exports.modules = {

/***/ "./pages/30/login-refreshtoken/index.tsx":
/*!***********************************************!*\
  !*** ./pages/30/login-refreshtoken/index.tsx ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LoginPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _src_commons_stores__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../src/commons/stores */ \"./src/commons/stores/index.ts\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var _src_commons_library_asyncFunc__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../../src/commons/library/asyncFunc */ \"./src/commons/library/asyncFunc.ts\");\n\n\n\n\n\n\n\nconst LOGIN_USER = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  mutation loginUserExample($email: String!, $password: String!) {\n    loginUserExample(email: $email, password: $password) {\n      accessToken\n    }\n  }\n`;\nfunction LoginPage() {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();\n    const { 0: email , 1: setEmail  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    const { 0: password , 1: setPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    const [, setAccessToken] = (0,recoil__WEBPACK_IMPORTED_MODULE_3__.useRecoilState)(_src_commons_stores__WEBPACK_IMPORTED_MODULE_4__.accessTokenState);\n    const [loginUserExample] = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useMutation)(LOGIN_USER);\n    const onChangeEmail = (event)=>{\n        setEmail(event.target.value);\n    };\n    const onChangePassword = (event)=>{\n        setPassword(event.target.value);\n    };\n    const onClickLogin = async ()=>{\n        try {\n            var ref;\n            // 1. 로그인 mutation 날려서 accessToken 받아오기\n            const result = await loginUserExample({\n                variables: {\n                    email,\n                    password\n                }\n            });\n            const accessToken = (ref = result.data) === null || ref === void 0 ? void 0 : ref.loginUserExample.accessToken;\n            if (accessToken === undefined) {\n                alert(\"로그인에 실패했습니다! 다시 시도해 주세요!\");\n                return;\n            } // accessToken의 타입에러 해결을 위해 작성\n            setAccessToken(accessToken);\n            // 3. 로그인 성공 페이지로 이동하기\n            void router.push(\"/30/login-refreshtoken-success\");\n        } catch (error) {\n            if (error instanceof Error) alert(error.message);\n        }\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            \"이메일 : \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"email\",\n                onChange: onChangeEmail\n            }, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/30/login-refreshtoken/index.tsx\",\n                lineNumber: 63,\n                columnNumber: 13\n            }, this),\n            \"비밀번호 : \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"password\",\n                onChange: onChangePassword\n            }, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/30/login-refreshtoken/index.tsx\",\n                lineNumber: 64,\n                columnNumber: 14\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: (0,_src_commons_library_asyncFunc__WEBPACK_IMPORTED_MODULE_6__.wrapAsync)(onClickLogin),\n                children: \"로그인\"\n            }, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/30/login-refreshtoken/index.tsx\",\n                lineNumber: 65,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8zMC9sb2dpbi1yZWZyZXNodG9rZW4vaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQWlEO0FBRWpCO0FBQ087QUFLdUI7QUFDdkI7QUFDMkI7QUFFbEUsS0FBSyxDQUFDTyxVQUFVLEdBQUdOLCtDQUFHLENBQUM7Ozs7OztBQU12QjtBQUVlLFFBQVEsQ0FBQ08sU0FBUyxHQUFnQixDQUFDO0lBQ2hELEtBQUssQ0FBQ0MsTUFBTSxHQUFHSixzREFBUztJQUN4QixLQUFLLE1BQUVLLEtBQUssTUFBRUMsUUFBUSxNQUFJVCwrQ0FBUSxDQUFDLENBQUU7SUFDckMsS0FBSyxNQUFFVSxRQUFRLE1BQUVDLFdBQVcsTUFBSVgsK0NBQVEsQ0FBQyxDQUFFO0lBRTNDLEtBQUssSUFBSVksY0FBYyxJQUFJWCxzREFBYyxDQUFDQyxpRUFBZ0I7SUFFMUQsS0FBSyxFQUFFVyxnQkFBZ0IsSUFBSWYsMkRBQVcsQ0FHcENPLFVBQVU7SUFFWixLQUFLLENBQUNTLGFBQWEsSUFBSUMsS0FBb0MsR0FBVyxDQUFDO1FBQ3JFTixRQUFRLENBQUNNLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLO0lBQzdCLENBQUM7SUFDRCxLQUFLLENBQUNDLGdCQUFnQixJQUFJSCxLQUFvQyxHQUFXLENBQUM7UUFDeEVKLFdBQVcsQ0FBQ0ksS0FBSyxDQUFDQyxNQUFNLENBQUNDLEtBQUs7SUFDaEMsQ0FBQztJQUNELEtBQUssQ0FBQ0UsWUFBWSxhQUE4QixDQUFDO1FBQy9DLEdBQUcsQ0FBQyxDQUFDO2dCQU1pQkMsR0FBVztZQUwvQixFQUEyRDtZQUMzRCxLQUFLLENBQUNBLE1BQU0sR0FBRyxLQUFLLENBQUNQLGdCQUFnQixDQUFDLENBQUM7Z0JBQ3JDUSxTQUFTLEVBQUUsQ0FBQztvQkFBQ2IsS0FBSztvQkFBRUUsUUFBUTtnQkFBQyxDQUFDO1lBQ2hDLENBQUM7WUFFRCxLQUFLLENBQUNZLFdBQVcsSUFBR0YsR0FBVyxHQUFYQSxNQUFNLENBQUNHLElBQUksY0FBWEgsR0FBVyxLQUFYQSxJQUFJLENBQUpBLENBQTZCLEdBQTdCQSxJQUFJLENBQUpBLENBQTZCLEdBQTdCQSxHQUFXLENBQUVQLGdCQUFnQixDQUFDUyxXQUFXO1lBRTdELEVBQUUsRUFBRUEsV0FBVyxLQUFLRSxTQUFTLEVBQUUsQ0FBQztnQkFDOUJDLEtBQUssQ0FBQyxDQUEwQjtnQkFDSSxNQUE5QjtZQUNSLENBQUMsQ0FBK0IsRUFBd0I7WUFDaENiLGNBQVYsQ0FBQ1UsV0FBVztZQUUxQixFQUFzQjtZQUNJLElBQXRCLENBQUNmLE1BQU0sQ0FBQ21CLElBQUksQ0FBQyxDQUFnQztRQUNuRCxDQUFDLENBQUMsS0FBSyxFQUFFQyxLQUFLLEVBQUUsQ0FBQztZQUNmLEVBQUUsRUFBRUEsS0FBSyxZQUFZQyxLQUFLLEVBQUVILEtBQUssQ0FBQ0UsS0FBSyxDQUFDRSxPQUFPO1FBQ2pELENBQUM7SUFDSCxDQUFDO0lBRUQsTUFBTTs7WUFDRixDQUNNO3dGQUFPQyxDQUFLO2dCQUFDQyxJQUFJLEVBQUMsQ0FBTztnQkFBQ0MsUUFBUSxFQUFFbEIsYUFBYTs7Ozs7O1lBQUksQ0FDOUM7d0ZBQUdnQixDQUFLO2dCQUFDQyxJQUFJLEVBQUMsQ0FBVTtnQkFBQ0MsUUFBUSxFQUFFZCxnQkFBZ0I7Ozs7Ozt3RkFDdkRlLENBQUY7Z0JBQUNDLE9BQU8sRUFBRTlCLHlFQUFTLENBQUNlLFlBQVk7MEJBQUcsQ0FBRzs7Ozs7Ozs7QUFHbkQsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NvZGVjYW1wLy4vcGFnZXMvMzAvbG9naW4tcmVmcmVzaHRva2VuL2luZGV4LnRzeD82YTU3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU11dGF0aW9uLCBncWwgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcbmltcG9ydCB0eXBlIHsgQ2hhbmdlRXZlbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VSZWNvaWxTdGF0ZSB9IGZyb20gXCJyZWNvaWxcIjtcbmltcG9ydCB0eXBlIHtcbiAgSU11dGF0aW9uLFxuICBJTXV0YXRpb25Mb2dpblVzZXJFeGFtcGxlQXJncyxcbn0gZnJvbSBcIi4uLy4uLy4uL3NyYy9jb21tb25zL3R5cGVzL2dlbmVyYXRlZC90eXBlc1wiO1xuaW1wb3J0IHsgYWNjZXNzVG9rZW5TdGF0ZSB9IGZyb20gXCIuLi8uLi8uLi9zcmMvY29tbW9ucy9zdG9yZXNcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IHsgd3JhcEFzeW5jIH0gZnJvbSBcIi4uLy4uLy4uL3NyYy9jb21tb25zL2xpYnJhcnkvYXN5bmNGdW5jXCI7XG5cbmNvbnN0IExPR0lOX1VTRVIgPSBncWxgXG4gIG11dGF0aW9uIGxvZ2luVXNlckV4YW1wbGUoJGVtYWlsOiBTdHJpbmchLCAkcGFzc3dvcmQ6IFN0cmluZyEpIHtcbiAgICBsb2dpblVzZXJFeGFtcGxlKGVtYWlsOiAkZW1haWwsIHBhc3N3b3JkOiAkcGFzc3dvcmQpIHtcbiAgICAgIGFjY2Vzc1Rva2VuXG4gICAgfVxuICB9XG5gO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMb2dpblBhZ2UoKTogSlNYLkVsZW1lbnQge1xuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcbiAgY29uc3QgW2VtYWlsLCBzZXRFbWFpbF0gPSB1c2VTdGF0ZShcIlwiKTtcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcblxuICBjb25zdCBbLCBzZXRBY2Nlc3NUb2tlbl0gPSB1c2VSZWNvaWxTdGF0ZShhY2Nlc3NUb2tlblN0YXRlKTtcblxuICBjb25zdCBbbG9naW5Vc2VyRXhhbXBsZV0gPSB1c2VNdXRhdGlvbjxcbiAgICBQaWNrPElNdXRhdGlvbiwgXCJsb2dpblVzZXJFeGFtcGxlXCI+LFxuICAgIElNdXRhdGlvbkxvZ2luVXNlckV4YW1wbGVBcmdzXG4gID4oTE9HSU5fVVNFUik7XG5cbiAgY29uc3Qgb25DaGFuZ2VFbWFpbCA9IChldmVudDogQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pOiB2b2lkID0+IHtcbiAgICBzZXRFbWFpbChldmVudC50YXJnZXQudmFsdWUpO1xuICB9O1xuICBjb25zdCBvbkNoYW5nZVBhc3N3b3JkID0gKGV2ZW50OiBDaGFuZ2VFdmVudDxIVE1MSW5wdXRFbGVtZW50Pik6IHZvaWQgPT4ge1xuICAgIHNldFBhc3N3b3JkKGV2ZW50LnRhcmdldC52YWx1ZSk7XG4gIH07XG4gIGNvbnN0IG9uQ2xpY2tMb2dpbiA9IGFzeW5jICgpOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgICB0cnkge1xuICAgICAgLy8gMS4g66Gc6re47J24IG11dGF0aW9uIOuCoOugpOyEnCBhY2Nlc3NUb2tlbiDrsJvslYTsmKTquLBcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGxvZ2luVXNlckV4YW1wbGUoe1xuICAgICAgICB2YXJpYWJsZXM6IHsgZW1haWwsIHBhc3N3b3JkIH0sXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgYWNjZXNzVG9rZW4gPSByZXN1bHQuZGF0YT8ubG9naW5Vc2VyRXhhbXBsZS5hY2Nlc3NUb2tlbjtcblxuICAgICAgaWYgKGFjY2Vzc1Rva2VuID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgYWxlcnQoXCLroZzqt7jsnbjsl5Ag7Iuk7Yyo7ZaI7Iq164uI64ukISDri6Tsi5wg7Iuc64+E7ZW0IOyjvOyEuOyalCFcIik7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH0gLy8gYWNjZXNzVG9rZW7snZgg7YOA7J6F7JeQ65+sIO2VtOqysOydhCDsnITtlbQg7J6R7ISxXG4gICAgICBzZXRBY2Nlc3NUb2tlbihhY2Nlc3NUb2tlbik7XG5cbiAgICAgIC8vIDMuIOuhnOq3uOyduCDshLHqs7Ug7Y6Y7J207KeA66GcIOydtOuPme2VmOq4sFxuICAgICAgdm9pZCByb3V0ZXIucHVzaChcIi8zMC9sb2dpbi1yZWZyZXNodG9rZW4tc3VjY2Vzc1wiKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIGFsZXJ0KGVycm9yLm1lc3NhZ2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICDsnbTrqZTsnbwgOiA8aW5wdXQgdHlwZT1cImVtYWlsXCIgb25DaGFuZ2U9e29uQ2hhbmdlRW1haWx9IC8+XG4gICAgICDruYTrsIDrsojtmLggOiA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgb25DaGFuZ2U9e29uQ2hhbmdlUGFzc3dvcmR9IC8+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9e3dyYXBBc3luYyhvbkNsaWNrTG9naW4pfT7roZzqt7jsnbg8L2J1dHRvbj5cbiAgICA8Lz5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJ1c2VNdXRhdGlvbiIsImdxbCIsInVzZVN0YXRlIiwidXNlUmVjb2lsU3RhdGUiLCJhY2Nlc3NUb2tlblN0YXRlIiwidXNlUm91dGVyIiwid3JhcEFzeW5jIiwiTE9HSU5fVVNFUiIsIkxvZ2luUGFnZSIsInJvdXRlciIsImVtYWlsIiwic2V0RW1haWwiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwic2V0QWNjZXNzVG9rZW4iLCJsb2dpblVzZXJFeGFtcGxlIiwib25DaGFuZ2VFbWFpbCIsImV2ZW50IiwidGFyZ2V0IiwidmFsdWUiLCJvbkNoYW5nZVBhc3N3b3JkIiwib25DbGlja0xvZ2luIiwicmVzdWx0IiwidmFyaWFibGVzIiwiYWNjZXNzVG9rZW4iLCJkYXRhIiwidW5kZWZpbmVkIiwiYWxlcnQiLCJwdXNoIiwiZXJyb3IiLCJFcnJvciIsIm1lc3NhZ2UiLCJpbnB1dCIsInR5cGUiLCJvbkNoYW5nZSIsImJ1dHRvbiIsIm9uQ2xpY2siXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/30/login-refreshtoken/index.tsx\n");

/***/ }),

/***/ "./src/commons/library/asyncFunc.ts":
/*!******************************************!*\
  !*** ./src/commons/library/asyncFunc.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"wrapAsync\": () => (/* binding */ wrapAsync),\n/* harmony export */   \"wrapFormAsync\": () => (/* binding */ wrapFormAsync)\n/* harmony export */ });\nconst wrapAsync = (asyncFunc)=>()=>{\n        void asyncFunc();\n    }\n;\nconst wrapFormAsync = (asyncFunc)=>{\n    return (event)=>{\n        event === null || event === void 0 ? void 0 : event.preventDefault();\n        void asyncFunc();\n    };\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9saWJyYXJ5L2FzeW5jRnVuYy50cy5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUVPLEtBQUssQ0FBQ0EsU0FBUyxJQUFJQyxTQUE4QixPQUFXLENBQUM7UUFDbEUsSUFBSSxDQUFDQSxTQUFTO0lBQ2hCLENBQUM7O0FBRU0sS0FBSyxDQUFDQyxhQUFhLElBQ3ZCRCxTQUE4QjtJQUFLLE1BQU0sRUFBTEUsS0FBaUMsR0FBSyxDQUFDO1FBQzFFQSxLQUFLLGFBQUxBLEtBQUssS0FBTEEsSUFBSSxDQUFKQSxDQUFxQixHQUFyQkEsSUFBSSxDQUFKQSxDQUFxQixHQUFyQkEsS0FBSyxDQUFFQyxjQUFjO1FBQ3JCLElBQUksQ0FBQ0gsU0FBUztJQUNoQixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY29kZWNhbXAvLi9zcmMvY29tbW9ucy9saWJyYXJ5L2FzeW5jRnVuYy50cz9kZjI3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB0eXBlIHsgRm9ybUV2ZW50IH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBjb25zdCB3cmFwQXN5bmMgPSAoYXN5bmNGdW5jOiAoKSA9PiBQcm9taXNlPHZvaWQ+KSA9PiAoKSA9PiB7XG4gIHZvaWQgYXN5bmNGdW5jKCk7XG59O1xuXG5leHBvcnQgY29uc3Qgd3JhcEZvcm1Bc3luYyA9XG4gIChhc3luY0Z1bmM6ICgpID0+IFByb21pc2U8dm9pZD4pID0+IChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pID0+IHtcbiAgICBldmVudD8ucHJldmVudERlZmF1bHQoKTtcbiAgICB2b2lkIGFzeW5jRnVuYygpO1xuICB9O1xuIl0sIm5hbWVzIjpbIndyYXBBc3luYyIsImFzeW5jRnVuYyIsIndyYXBGb3JtQXN5bmMiLCJldmVudCIsInByZXZlbnREZWZhdWx0Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/commons/library/asyncFunc.ts\n");

/***/ }),

/***/ "./src/commons/library/getAccessToken.ts":
/*!***********************************************!*\
  !*** ./src/commons/library/getAccessToken.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"getAccessToken\": () => (/* binding */ getAccessToken)\n/* harmony export */ });\n/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! graphql-request */ \"graphql-request\");\n/* harmony import */ var graphql_request__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(graphql_request__WEBPACK_IMPORTED_MODULE_0__);\n\nconst RESTORE_ACCESS_TOKEN = graphql_request__WEBPACK_IMPORTED_MODULE_0__.gql`\n  mutation {\n    restoreAccessToken {\n      accessToken\n      # 재발급 받기\n    }\n  }\n`;\nconst getAccessToken = async ()=>{\n    try {\n        const graphQLClient = new graphql_request__WEBPACK_IMPORTED_MODULE_0__.GraphQLClient(\"https://backend-practice.codebootcamp.co.kr/graphql\", {\n            credentials: \"include\"\n        });\n        const result = await graphQLClient.request(RESTORE_ACCESS_TOKEN);\n        const newAccessToken = result.restoreAccessToken.accessToken;\n        return newAccessToken;\n    } catch (error) {\n        if (error instanceof Error) console.log(error.message);\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9saWJyYXJ5L2dldEFjY2Vzc1Rva2VuLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFvRDtBQUVwRCxLQUFLLENBQUNFLG9CQUFvQixHQUFHRixnREFBRyxDQUFDOzs7Ozs7O0FBT2pDO0FBRU8sS0FBSyxDQUFDRyxjQUFjLGFBQTRDLENBQUM7SUFDdEUsR0FBRyxDQUFDLENBQUM7UUFDSCxLQUFLLENBQUNDLGFBQWEsR0FBRyxHQUFHLENBQUNILDBEQUFhLENBQ3JDLENBQXFELHNEQUNyRCxDQUFDO1lBQUNJLFdBQVcsRUFBRSxDQUFTO1FBQUMsQ0FBQztRQUU1QixLQUFLLENBQUNDLE1BQU0sR0FBRyxLQUFLLENBQUNGLGFBQWEsQ0FBQ0csT0FBTyxDQUFDTCxvQkFBb0I7UUFDL0QsS0FBSyxDQUFDTSxjQUFjLEdBQUdGLE1BQU0sQ0FBQ0csa0JBQWtCLENBQUNDLFdBQVc7UUFDNUQsTUFBTSxDQUFDRixjQUFjO0lBQ3ZCLENBQUMsQ0FBQyxLQUFLLEVBQUVHLEtBQUssRUFBRSxDQUFDO1FBQ2YsRUFBRSxFQUFFQSxLQUFLLFlBQVlDLEtBQUssRUFBRUMsT0FBTyxDQUFDQyxHQUFHLENBQUNILEtBQUssQ0FBQ0ksT0FBTztJQUN2RCxDQUFDO0FBQ0gsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NvZGVjYW1wLy4vc3JjL2NvbW1vbnMvbGlicmFyeS9nZXRBY2Nlc3NUb2tlbi50cz84ODlkIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGdxbCwgR3JhcGhRTENsaWVudCB9IGZyb20gXCJncmFwaHFsLXJlcXVlc3RcIjtcblxuY29uc3QgUkVTVE9SRV9BQ0NFU1NfVE9LRU4gPSBncWxgXG4gIG11dGF0aW9uIHtcbiAgICByZXN0b3JlQWNjZXNzVG9rZW4ge1xuICAgICAgYWNjZXNzVG9rZW5cbiAgICAgICMg7J6s67Cc6riJIOuwm+q4sFxuICAgIH1cbiAgfVxuYDtcblxuZXhwb3J0IGNvbnN0IGdldEFjY2Vzc1Rva2VuID0gYXN5bmMgKCk6IFByb21pc2U8c3RyaW5nIHwgdW5kZWZpbmVkPiA9PiB7XG4gIHRyeSB7XG4gICAgY29uc3QgZ3JhcGhRTENsaWVudCA9IG5ldyBHcmFwaFFMQ2xpZW50KFxuICAgICAgXCJodHRwczovL2JhY2tlbmQtcHJhY3RpY2UuY29kZWJvb3RjYW1wLmNvLmtyL2dyYXBocWxcIixcbiAgICAgIHsgY3JlZGVudGlhbHM6IFwiaW5jbHVkZVwiIH1cbiAgICApO1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGdyYXBoUUxDbGllbnQucmVxdWVzdChSRVNUT1JFX0FDQ0VTU19UT0tFTik7XG4gICAgY29uc3QgbmV3QWNjZXNzVG9rZW4gPSByZXN1bHQucmVzdG9yZUFjY2Vzc1Rva2VuLmFjY2Vzc1Rva2VuO1xuICAgIHJldHVybiBuZXdBY2Nlc3NUb2tlbjtcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikgY29uc29sZS5sb2coZXJyb3IubWVzc2FnZSk7XG4gIH1cbn07XG4iXSwibmFtZXMiOlsiZ3FsIiwiR3JhcGhRTENsaWVudCIsIlJFU1RPUkVfQUNDRVNTX1RPS0VOIiwiZ2V0QWNjZXNzVG9rZW4iLCJncmFwaFFMQ2xpZW50IiwiY3JlZGVudGlhbHMiLCJyZXN1bHQiLCJyZXF1ZXN0IiwibmV3QWNjZXNzVG9rZW4iLCJyZXN0b3JlQWNjZXNzVG9rZW4iLCJhY2Nlc3NUb2tlbiIsImVycm9yIiwiRXJyb3IiLCJjb25zb2xlIiwibG9nIiwibWVzc2FnZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/library/getAccessToken.ts\n");

/***/ }),

/***/ "./src/commons/stores/index.ts":
/*!*************************************!*\
  !*** ./src/commons/stores/index.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"accessTokenState\": () => (/* binding */ accessTokenState),\n/* harmony export */   \"restoreAccessTokenLoadable\": () => (/* binding */ restoreAccessTokenLoadable)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _library_getAccessToken__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../library/getAccessToken */ \"./src/commons/library/getAccessToken.ts\");\n\n\nconst accessTokenState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"accessTokenState\",\n    default: \"\"\n});\nconst restoreAccessTokenLoadable = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.selector)({\n    key: \"restoreAccessTokenLoadable\",\n    get: async ()=>{\n        const newAccessToken = await (0,_library_getAccessToken__WEBPACK_IMPORTED_MODULE_1__.getAccessToken)();\n        return newAccessToken;\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdG9yZXMvaW5kZXgudHMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBdUM7QUFDbUI7QUFFbkQsS0FBSyxDQUFDRyxnQkFBZ0IsR0FBR0gsNENBQUksQ0FBQyxDQUFDO0lBQ3BDSSxHQUFHLEVBQUUsQ0FBa0I7SUFDdkJDLE9BQU8sRUFBRSxDQUFFO0FBQ2IsQ0FBQztBQUVNLEtBQUssQ0FBQ0MsMEJBQTBCLEdBQUdMLGdEQUFRLENBQUMsQ0FBQztJQUNsREcsR0FBRyxFQUFFLENBQTRCO0lBQ2pDRyxHQUFHLFlBQWMsQ0FBQztRQUNoQixLQUFLLENBQUNDLGNBQWMsR0FBRyxLQUFLLENBQUNOLHVFQUFjO1FBQzNDLE1BQU0sQ0FBQ00sY0FBYztJQUN2QixDQUFDO0FBQ0gsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NvZGVjYW1wLy4vc3JjL2NvbW1vbnMvc3RvcmVzL2luZGV4LnRzPzIwYjQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXRvbSwgc2VsZWN0b3IgfSBmcm9tIFwicmVjb2lsXCI7XG5pbXBvcnQgeyBnZXRBY2Nlc3NUb2tlbiB9IGZyb20gXCIuLi9saWJyYXJ5L2dldEFjY2Vzc1Rva2VuXCI7XG5cbmV4cG9ydCBjb25zdCBhY2Nlc3NUb2tlblN0YXRlID0gYXRvbSh7XG4gIGtleTogXCJhY2Nlc3NUb2tlblN0YXRlXCIsXG4gIGRlZmF1bHQ6IFwiXCIsXG59KTtcblxuZXhwb3J0IGNvbnN0IHJlc3RvcmVBY2Nlc3NUb2tlbkxvYWRhYmxlID0gc2VsZWN0b3Ioe1xuICBrZXk6IFwicmVzdG9yZUFjY2Vzc1Rva2VuTG9hZGFibGVcIixcbiAgZ2V0OiBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgbmV3QWNjZXNzVG9rZW4gPSBhd2FpdCBnZXRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBuZXdBY2Nlc3NUb2tlbjtcbiAgfSxcbn0pO1xuIl0sIm5hbWVzIjpbImF0b20iLCJzZWxlY3RvciIsImdldEFjY2Vzc1Rva2VuIiwiYWNjZXNzVG9rZW5TdGF0ZSIsImtleSIsImRlZmF1bHQiLCJyZXN0b3JlQWNjZXNzVG9rZW5Mb2FkYWJsZSIsImdldCIsIm5ld0FjY2Vzc1Rva2VuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/commons/stores/index.ts\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "graphql-request":
/*!**********************************!*\
  !*** external "graphql-request" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("graphql-request");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/30/login-refreshtoken/index.tsx"));
module.exports = __webpack_exports__;

})();