"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/21-1-2/container";
exports.ids = ["pages/21-1-2/container"];
exports.modules = {

/***/ "./pages/21-1-2/container/index.tsx":
/*!******************************************!*\
  !*** ./pages/21-1-2/container/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Container)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _presenter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../presenter */ \"./pages/21-1-2/presenter/index.tsx\");\n\n\nfunction Container() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_presenter__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n            child: \"철수\",\n            age: 13\n        }, void 0, false, {\n            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/21-1-2/container/index.tsx\",\n            lineNumber: 6,\n            columnNumber: 7\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMS0xLTIvY29udGFpbmVyL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFvQztBQUVyQixRQUFRLENBQUNDLFNBQVMsR0FBZ0IsQ0FBQztJQUNoRCxNQUFNOzhGQUVERCxrREFBUztZQUFDRSxLQUFLLEVBQUMsQ0FBSTtZQUFDQyxHQUFHLEVBQUUsRUFBRTs7Ozs7OztBQUduQyxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3BhZ2VzLzIxLTEtMi9jb250YWluZXIvaW5kZXgudHN4PzNjNGEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFByZXNlbnRlciBmcm9tIFwiLi4vcHJlc2VudGVyXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnRhaW5lcigpOiBKU1guRWxlbWVudCB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxQcmVzZW50ZXIgY2hpbGQ9XCLssqDsiJhcIiBhZ2U9ezEzfSAvPlxuICAgIDwvPlxuICApO1xufVxuIl0sIm5hbWVzIjpbIlByZXNlbnRlciIsIkNvbnRhaW5lciIsImNoaWxkIiwiYWdlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/21-1-2/container/index.tsx\n");

/***/ }),

/***/ "./pages/21-1-2/presenter/index.tsx":
/*!******************************************!*\
  !*** ./pages/21-1-2/presenter/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Presenter)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction Presenter(props) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            props.child,\n            \"는 \",\n            props.age,\n            \"살 입니다.\"\n        ]\n    }, void 0, true, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/21-1-2/presenter/index.tsx\",\n        lineNumber: 3,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMS0xLTIvcHJlc2VudGVyL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQWUsUUFBUSxDQUFDQSxTQUFTLENBQUNDLEtBQVUsRUFBRSxDQUFDO0lBQzdDLE1BQU0sNkVBQ0hDLENBQUc7O1lBQ0RELEtBQUssQ0FBQ0UsS0FBSztZQUFDLENBQUU7WUFBR0YsS0FBSyxDQUFDRyxHQUFHO1lBQUMsQ0FDNUI7Ozs7Ozs7QUFFSixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3BhZ2VzLzIxLTEtMi9wcmVzZW50ZXIvaW5kZXgudHN4PzJlMjQiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUHJlc2VudGVyKHByb3BzOiBhbnkpIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAge3Byb3BzLmNoaWxkfeuKlCB7cHJvcHMuYWdlfeyCtCDsnoXri4jri6QuXG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwibmFtZXMiOlsiUHJlc2VudGVyIiwicHJvcHMiLCJkaXYiLCJjaGlsZCIsImFnZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/21-1-2/presenter/index.tsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/21-1-2/container/index.tsx"));
module.exports = __webpack_exports__;

})();