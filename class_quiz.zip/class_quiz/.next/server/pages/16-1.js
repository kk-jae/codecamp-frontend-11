"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/16-1";
exports.ids = ["pages/16-1"];
exports.modules = {

/***/ "./pages/16-1/index.tsx":
/*!******************************!*\
  !*** ./pages/16-1/index.tsx ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* export default binding */ __WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-infinite-scroller */ \"react-infinite-scroller\");\n/* harmony import */ var react_infinite_scroller__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_infinite_scroller__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst FETCH_BOARDS = _apollo_client__WEBPACK_IMPORTED_MODULE_2__.gql`\n  query fetchBoards($page: Int) {\n    fetchBoards(page: $page) {\n      writer\n      title\n      _id\n      createdAt\n    }\n  }\n`;\n/* harmony default export */ function __WEBPACK_DEFAULT_EXPORT__() {\n    const { data , fetchMore  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_2__.useQuery)(FETCH_BOARDS);\n    const loadFunc = ()=>{\n        if (data == undefined) return;\n        var _length;\n        fetchMore({\n            variables: {\n                page: Math.ceil(((_length = data === null || data === void 0 ? void 0 : data.fetchBoards.length) !== null && _length !== void 0 ? _length : 10) / 10) + 1\n            },\n            updateQuery: (prev, { fetchMoreResult  })=>{\n                if (fetchMoreResult.fetchBoards === undefined) {\n                    return {\n                        fetchBoards: [\n                            ...prev.fetchBoards\n                        ]\n                    };\n                }\n                return {\n                    fetchBoards: [\n                        ...prev.fetchBoards,\n                        ...fetchMoreResult.fetchBoards\n                    ]\n                };\n            }\n        });\n    };\n    var ref;\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        style: {\n            height: \"500px\",\n            overflow: \"auto\"\n        },\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_infinite_scroller__WEBPACK_IMPORTED_MODULE_1___default()), {\n            pageStart: 0,\n            loadMore: loadFunc,\n            hasMore: true,\n            useWindow: false,\n            children: (ref = data === null || data === void 0 ? void 0 : data.fetchBoards.map((el)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                            style: {\n                                margin: \"10px\"\n                            },\n                            children: el.writer\n                        }, void 0, false, {\n                            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/16-1/index.tsx\",\n                            lineNumber: 52,\n                            columnNumber: 13\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                            style: {\n                                margin: \"10px\"\n                            },\n                            children: el.title\n                        }, void 0, false, {\n                            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/16-1/index.tsx\",\n                            lineNumber: 53,\n                            columnNumber: 13\n                        }, this)\n                    ]\n                }, el._id, true, {\n                    fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/16-1/index.tsx\",\n                    lineNumber: 51,\n                    columnNumber: 11\n                }, this)\n            )) !== null && ref !== void 0 ? ref : /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, void 0, false)\n        }, void 0, false, {\n            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/16-1/index.tsx\",\n            lineNumber: 44,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/16-1/index.tsx\",\n        lineNumber: 43,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNi0xL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFvRDtBQUNOO0FBTTlDLEtBQUssQ0FBQ0csWUFBWSxHQUFHRiwrQ0FBRyxDQUFDOzs7Ozs7Ozs7QUFTekI7QUFFQSw2QkFBZSxzQ0FBWSxDQUFDO0lBQzFCLEtBQUssQ0FBQyxDQUFDLENBQUNHLElBQUksR0FBRUMsU0FBUyxFQUFDLENBQUMsR0FBR0gsd0RBQVEsQ0FHbENDLFlBQVk7SUFFZCxLQUFLLENBQUNHLFFBQVEsT0FBUyxDQUFDO1FBQ3RCLEVBQUUsRUFBRUYsSUFBSSxJQUFJRyxTQUFTLEVBQUUsTUFBTTtZQUVHSCxPQUF3QjtRQUR4REMsU0FBUyxDQUFDLENBQUM7WUFDVEcsU0FBUyxFQUFFLENBQUM7Z0JBQUNDLElBQUksRUFBRUMsSUFBSSxDQUFDQyxJQUFJLEdBQUVQLE9BQXdCLEdBQXhCQSxJQUFJLGFBQUpBLElBQUksS0FBSkEsSUFBSSxDQUFKQSxDQUFpQixHQUFqQkEsSUFBSSxDQUFKQSxDQUFpQixHQUFqQkEsSUFBSSxDQUFFUSxXQUFXLENBQUNDLE1BQU0sY0FBeEJULE9BQXdCLGNBQXhCQSxPQUF3QixHQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQztZQUFDLENBQUM7WUFDekVVLFdBQVcsR0FBR0MsSUFBSSxFQUFFLENBQUMsQ0FBQ0MsZUFBZSxFQUFDLENBQUMsR0FBSyxDQUFDO2dCQUMzQyxFQUFFLEVBQUVBLGVBQWUsQ0FBQ0osV0FBVyxLQUFLTCxTQUFTLEVBQUUsQ0FBQztvQkFDOUMsTUFBTSxDQUFDLENBQUM7d0JBQ05LLFdBQVcsRUFBRSxDQUFDOytCQUFHRyxJQUFJLENBQUNILFdBQVc7d0JBQUEsQ0FBQztvQkFDcEMsQ0FBQztnQkFDSCxDQUFDO2dCQUNELE1BQU0sQ0FBQyxDQUFDO29CQUNOQSxXQUFXLEVBQUUsQ0FBQzsyQkFBR0csSUFBSSxDQUFDSCxXQUFXOzJCQUFLSSxlQUFlLENBQUNKLFdBQVc7b0JBQUEsQ0FBQztnQkFDcEUsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztRQVVNUixHQUtDO0lBYlIsTUFBTSw2RUFDSGEsQ0FBRztRQUFDQyxLQUFLLEVBQUUsQ0FBQztZQUFDQyxNQUFNLEVBQUUsQ0FBTztZQUFFQyxRQUFRLEVBQUUsQ0FBTTtRQUFDLENBQUM7OEZBQzlDcEIsZ0VBQWM7WUFDYnFCLFNBQVMsRUFBRSxDQUFDO1lBQ1pDLFFBQVEsRUFBRWhCLFFBQVE7WUFDbEJpQixPQUFPLEVBQUUsSUFBSTtZQUNiQyxTQUFTLEVBQUUsS0FBSzt1QkFFZnBCLEdBS0MsR0FMREEsSUFBSSxhQUFKQSxJQUFJLEtBQUpBLElBQUksQ0FBSkEsQ0FBaUIsR0FBakJBLElBQUksQ0FBSkEsQ0FBaUIsR0FBakJBLElBQUksQ0FBRVEsV0FBVyxDQUFDYSxHQUFHLEVBQUVDLEVBQUUsK0VBQ3ZCVCxDQUFHOztvR0FDRFUsQ0FBSTs0QkFBQ1QsS0FBSyxFQUFFLENBQUM7Z0NBQUNVLE1BQU0sRUFBRSxDQUFNOzRCQUFDLENBQUM7c0NBQUdGLEVBQUUsQ0FBQ0csTUFBTTs7Ozs7O29HQUMxQ0YsQ0FBSTs0QkFBQ1QsS0FBSyxFQUFFLENBQUM7Z0NBQUNVLE1BQU0sRUFBRSxDQUFNOzRCQUFDLENBQUM7c0NBQUdGLEVBQUUsQ0FBQ0ksS0FBSzs7Ozs7OzttQkFGbENKLEVBQUUsQ0FBQ0ssR0FBRzs7Ozs7MkJBRGpCM0IsR0FLQyxjQUxEQSxHQUtDOzs7Ozs7Ozs7OztBQUlWLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vcGFnZXMvMTYtMS9pbmRleC50c3g/NGM0NiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSW5maW5pdGVTY3JvbGwgZnJvbSBcInJlYWN0LWluZmluaXRlLXNjcm9sbGVyXCI7XG5pbXBvcnQgeyBncWwsIHVzZVF1ZXJ5IH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5pbXBvcnQgdHlwZSB7XG4gIElRdWVyeSxcbiAgSVF1ZXJ5RmV0Y2hCb2FyZHNBcmdzLFxufSBmcm9tIFwiLi4vLi4vc3JjL2NvbW1vbnMvdHlwZXMvZ2VuZXJhdGVkL3R5cGVzXCI7XG5cbmNvbnN0IEZFVENIX0JPQVJEUyA9IGdxbGBcbiAgcXVlcnkgZmV0Y2hCb2FyZHMoJHBhZ2U6IEludCkge1xuICAgIGZldGNoQm9hcmRzKHBhZ2U6ICRwYWdlKSB7XG4gICAgICB3cml0ZXJcbiAgICAgIHRpdGxlXG4gICAgICBfaWRcbiAgICAgIGNyZWF0ZWRBdFxuICAgIH1cbiAgfVxuYDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKCkge1xuICBjb25zdCB7IGRhdGEsIGZldGNoTW9yZSB9ID0gdXNlUXVlcnk8XG4gICAgUGljazxJUXVlcnksIFwiZmV0Y2hCb2FyZHNcIj4sXG4gICAgSVF1ZXJ5RmV0Y2hCb2FyZHNBcmdzXG4gID4oRkVUQ0hfQk9BUkRTKTtcblxuICBjb25zdCBsb2FkRnVuYyA9ICgpID0+IHtcbiAgICBpZiAoZGF0YSA9PSB1bmRlZmluZWQpIHJldHVybjtcbiAgICBmZXRjaE1vcmUoe1xuICAgICAgdmFyaWFibGVzOiB7IHBhZ2U6IE1hdGguY2VpbCgoZGF0YT8uZmV0Y2hCb2FyZHMubGVuZ3RoID8/IDEwKSAvIDEwKSArIDEgfSxcbiAgICAgIHVwZGF0ZVF1ZXJ5OiAocHJldiwgeyBmZXRjaE1vcmVSZXN1bHQgfSkgPT4ge1xuICAgICAgICBpZiAoZmV0Y2hNb3JlUmVzdWx0LmZldGNoQm9hcmRzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZmV0Y2hCb2FyZHM6IFsuLi5wcmV2LmZldGNoQm9hcmRzXSxcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZmV0Y2hCb2FyZHM6IFsuLi5wcmV2LmZldGNoQm9hcmRzLCAuLi5mZXRjaE1vcmVSZXN1bHQuZmV0Y2hCb2FyZHNdLFxuICAgICAgICB9O1xuICAgICAgfSxcbiAgICB9KTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgaGVpZ2h0OiBcIjUwMHB4XCIsIG92ZXJmbG93OiBcImF1dG9cIiB9fT5cbiAgICAgIDxJbmZpbml0ZVNjcm9sbFxuICAgICAgICBwYWdlU3RhcnQ9ezB9XG4gICAgICAgIGxvYWRNb3JlPXtsb2FkRnVuY31cbiAgICAgICAgaGFzTW9yZT17dHJ1ZX1cbiAgICAgICAgdXNlV2luZG93PXtmYWxzZX1cbiAgICAgID5cbiAgICAgICAge2RhdGE/LmZldGNoQm9hcmRzLm1hcCgoZWwpID0+IChcbiAgICAgICAgICA8ZGl2IGtleT17ZWwuX2lkfT5cbiAgICAgICAgICAgIDxzcGFuIHN0eWxlPXt7IG1hcmdpbjogXCIxMHB4XCIgfX0+e2VsLndyaXRlcn08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBzdHlsZT17eyBtYXJnaW46IFwiMTBweFwiIH19PntlbC50aXRsZX08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpID8/IDw+PC8+fVxuICAgICAgPC9JbmZpbml0ZVNjcm9sbD5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJJbmZpbml0ZVNjcm9sbCIsImdxbCIsInVzZVF1ZXJ5IiwiRkVUQ0hfQk9BUkRTIiwiZGF0YSIsImZldGNoTW9yZSIsImxvYWRGdW5jIiwidW5kZWZpbmVkIiwidmFyaWFibGVzIiwicGFnZSIsIk1hdGgiLCJjZWlsIiwiZmV0Y2hCb2FyZHMiLCJsZW5ndGgiLCJ1cGRhdGVRdWVyeSIsInByZXYiLCJmZXRjaE1vcmVSZXN1bHQiLCJkaXYiLCJzdHlsZSIsImhlaWdodCIsIm92ZXJmbG93IiwicGFnZVN0YXJ0IiwibG9hZE1vcmUiLCJoYXNNb3JlIiwidXNlV2luZG93IiwibWFwIiwiZWwiLCJzcGFuIiwibWFyZ2luIiwid3JpdGVyIiwidGl0bGUiLCJfaWQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/16-1/index.tsx\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react-infinite-scroller":
/*!******************************************!*\
  !*** external "react-infinite-scroller" ***!
  \******************************************/
/***/ ((module) => {

module.exports = require("react-infinite-scroller");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/16-1/index.tsx"));
module.exports = __webpack_exports__;

})();