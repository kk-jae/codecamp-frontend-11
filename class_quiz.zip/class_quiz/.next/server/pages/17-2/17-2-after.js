"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/17-2/17-2-after";
exports.ids = ["pages/17-2/17-2-after"];
exports.modules = {

/***/ "./pages/17-2/17-2-after/index.tsx":
/*!*****************************************!*\
  !*** ./pages/17-2/17-2-after/index.tsx ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyComponent)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction MyComponent() {\n    const { 0: count , 1: setCount  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(0);\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        console.log(\"컴포넌트가 마운트됐습니다~\");\n        return ()=>{\n            alert(\"컴포넌트가 제거됩니다~\");\n        };\n    }, []);\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        console.log(\"컴포넌트가 변경됐습니다~\");\n    });\n    // useEffect(() => {\n    //   return () => {\n    //     alert(\"컴포넌트가 제거됩니다~\");\n    //   };\n    // }, []);\n    const onClickCounter = ()=>{\n        setCount((prev)=>prev + 1\n        );\n    };\n    const onClickMove = ()=>{\n        router.push(\"/\");\n    };\n    console.log(\"마운트 시작\");\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: [\n                    \"카운트: \",\n                    count\n                ]\n            }, void 0, true, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-2/17-2-after/index.tsx\",\n                lineNumber: 37,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickCounter,\n                children: \"카운트(+1)\"\n            }, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-2/17-2-after/index.tsx\",\n                lineNumber: 38,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickMove,\n                children: \"이동하기\"\n            }, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-2/17-2-after/index.tsx\",\n                lineNumber: 39,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNy0yLzE3LTItYWZ0ZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQXVDO0FBQ0k7QUFFNUIsUUFBUSxDQUFDRyxXQUFXLEdBQUcsQ0FBQztJQUNyQyxLQUFLLE1BQUVDLEtBQUssTUFBRUMsUUFBUSxNQUFJSCwrQ0FBUSxDQUFDLENBQUM7SUFDcEMsS0FBSyxDQUFDSSxNQUFNLEdBQUdOLHNEQUFTO0lBRXhCQyxnREFBUyxLQUFPLENBQUM7UUFDZk0sT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBZ0I7UUFDSixNQUFsQixLQUFPLENBQUM7WUFDWkMsS0FBSyxDQUFDLENBQWM7UUFDRixDQUFuQjtJQUNILENBQUMsRUFBRSxDQUFDLENBQUM7SUFFTFIsZ0RBQVMsS0FBTyxDQUFDO1FBQ2ZNLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQWU7SUFDUCxDQUFyQjtJQUVELEVBQW9CO0lBQ3BCLEVBQW1CO0lBQ25CLEVBQTZCO0lBQ1QsRUFBYjtJQUNQLEVBQVU7SUFFVixLQUFLLENBQUNFLGNBQWMsT0FBUyxDQUFDO1FBQzVCTCxRQUFRLEVBQUVNLElBQUksR0FBS0EsSUFBSSxHQUFHLENBQUM7O0lBQzdCLENBQUM7SUFFRCxLQUFLLENBQUNDLFdBQVcsT0FBUyxDQUFDO1FBQ3pCTixNQUFNLENBQUNPLElBQUksQ0FBQyxDQUFHO0lBQ2pCLENBQUM7SUFFRE4sT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBUTtJQUVWLE1BQUo7O3dGQUVETSxDQUFHOztvQkFBQyxDQUFLO29CQUFPVixLQUFLOzs7Ozs7O3dGQUNmVyxDQUFBO2dCQUFDQyxPQUFPLEVBQUVOLGNBQWM7MEJBQUUsQ0FBTzs7Ozs7O3dGQUNqQ0ssQ0FBQTtnQkFBQ0MsT0FBTyxFQUFFSixXQUFXOzBCQUFFLENBQUk7Ozs7Ozs7O0FBR3hDLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vcGFnZXMvMTctMi8xNy0yLWFmdGVyL2luZGV4LnRzeD8xYTBjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNeUNvbXBvbmVudCgpIHtcbiAgY29uc3QgW2NvdW50LCBzZXRDb3VudF0gPSB1c2VTdGF0ZSgwKTtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zb2xlLmxvZyhcIuy7tO2PrOuEjO2KuOqwgCDrp4jsmrTtirjrkJDsirXri4jri6R+XCIpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBhbGVydChcIuy7tO2PrOuEjO2KuOqwgCDsoJzqsbDrkKnri4jri6R+XCIpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnNvbGUubG9nKFwi7Lu07Y+s64SM7Yq46rCAIOuzgOqyveuQkOyKteuLiOuLpH5cIik7XG4gIH0pO1xuXG4gIC8vIHVzZUVmZmVjdCgoKSA9PiB7XG4gIC8vICAgcmV0dXJuICgpID0+IHtcbiAgLy8gICAgIGFsZXJ0KFwi7Lu07Y+s64SM7Yq46rCAIOygnOqxsOuQqeuLiOuLpH5cIik7XG4gIC8vICAgfTtcbiAgLy8gfSwgW10pO1xuXG4gIGNvbnN0IG9uQ2xpY2tDb3VudGVyID0gKCkgPT4ge1xuICAgIHNldENvdW50KChwcmV2KSA9PiBwcmV2ICsgMSk7XG4gIH07XG5cbiAgY29uc3Qgb25DbGlja01vdmUgPSAoKSA9PiB7XG4gICAgcm91dGVyLnB1c2goXCIvXCIpO1xuICB9O1xuXG4gIGNvbnNvbGUubG9nKFwi66eI7Jq07Yq4IOyLnOyekVwiKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2Puy5tOyatO2KuDoge2NvdW50fTwvZGl2PlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrQ291bnRlcn0+7Lm07Jq07Yq4KCsxKTwvYnV0dG9uPlxuICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrTW92ZX0+7J2064+Z7ZWY6riwPC9idXR0b24+XG4gICAgPC8+XG4gICk7XG59XG4iXSwibmFtZXMiOlsidXNlUm91dGVyIiwidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJNeUNvbXBvbmVudCIsImNvdW50Iiwic2V0Q291bnQiLCJyb3V0ZXIiLCJjb25zb2xlIiwibG9nIiwiYWxlcnQiLCJvbkNsaWNrQ291bnRlciIsInByZXYiLCJvbkNsaWNrTW92ZSIsInB1c2giLCJkaXYiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/17-2/17-2-after/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/17-2/17-2-after/index.tsx"));
module.exports = __webpack_exports__;

})();