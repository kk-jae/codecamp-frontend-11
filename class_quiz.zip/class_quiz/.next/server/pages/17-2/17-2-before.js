"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/17-2/17-2-before";
exports.ids = ["pages/17-2/17-2-before"];
exports.modules = {

/***/ "./pages/17-2/17-2-before/index.tsx":
/*!******************************************!*\
  !*** ./pages/17-2/17-2-before/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MyComponent)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nclass MyComponent extends react__WEBPACK_IMPORTED_MODULE_2__.Component {\n    componentDidMount() {\n        console.log(\"컴포넌트가 마운트됐습니다~\");\n    }\n    componentDidUpdate() {\n        console.log(\"컴포넌트가 변경됐습니다~\");\n    }\n    componentWillUnmount() {\n        alert(\"컴포넌트가 제거됩니다~\");\n    }\n    render() {\n        console.log(\"마운트 시작\");\n        return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: [\n                        \"카운트: \",\n                        this.state.count\n                    ]\n                }, void 0, true, {\n                    fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-2/17-2-before/index.tsx\",\n                    lineNumber: 33,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    onClick: this.onClickCounter,\n                    children: \"카운트(+1)\"\n                }, void 0, false, {\n                    fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-2/17-2-before/index.tsx\",\n                    lineNumber: 34,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                    onClick: this.onClickMove,\n                    children: \"이동하기\"\n                }, void 0, false, {\n                    fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/17-2/17-2-before/index.tsx\",\n                    lineNumber: 35,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true));\n    }\n    constructor(...args){\n        super(...args);\n        this.state = {\n            count: 0\n        };\n        this.onClickCounter = ()=>{\n            this.setState((prev)=>({\n                    count: prev.count + 1\n                })\n            );\n        };\n        this.onClickMove = ()=>{\n            next_router__WEBPACK_IMPORTED_MODULE_1___default().push(\"/\");\n        };\n    }\n}\n\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8xNy0yLzE3LTItYmVmb3JlL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7OztBQUFnQztBQUNDO01BRVpFLFdBQVcsU0FBU0QsNENBQVM7SUFLaERFLGlCQUFpQixHQUFHLENBQUM7UUFDbkJDLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQWdCO0lBQ04sQ0FBdkI7SUFFREMsa0JBQWtCLEdBQUcsQ0FBQztRQUNwQkYsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBZTtJQUNQLENBQXJCO0lBRURFLG9CQUFvQixHQUFHLENBQUM7UUFDdEJDLEtBQUssQ0FBQyxDQUFjO0lBQ0YsQ0FBbkI7SUFVREMsTUFBTSxHQUFHLENBQUM7UUFDUkwsT0FBTyxDQUFDQyxHQUFHLENBQUMsQ0FBUTtRQUNWLE1BQUo7OzRGQUVESyxDQUFHOzt3QkFBQyxDQUFLO3dCQUFPLElBQUksQ0FBQ0MsS0FBSyxDQUFDQyxLQUFLOzs7Ozs7OzRGQUMxQkMsQ0FBQTtvQkFBQ0MsT0FBTyxFQUFFLElBQUksQ0FBQ0MsY0FBYzs4QkFBRSxDQUFPOzs7Ozs7NEZBQ3RDRixDQUFBO29CQUFDQyxPQUFPLEVBQUUsSUFBSSxDQUFDRSxXQUFXOzhCQUFFLENBQUk7Ozs7Ozs7O0lBRzdDLENBQUM7OztRQWxDWSxJQW1DZCxDQWxDQ0wsS0FBSyxHQUFHLENBQUM7WUFDUEMsS0FBSyxFQUFFLENBQUM7UUFDVixDQUFDO1FBSFksSUFtQ2QsQ0FsQkNHLGNBQWMsT0FBUyxDQUFDO1lBQ3RCLElBQUksQ0FBQ0UsUUFBUSxFQUFFQyxJQUF1QixJQUFNLENBQUM7b0JBQUNOLEtBQUssRUFBRU0sSUFBSSxDQUFDTixLQUFLLEdBQUcsQ0FBQztnQkFBQyxDQUFDOztRQUN2RSxDQUFDO1FBbkJZLElBbUNkLENBZENJLFdBQVcsT0FBUyxDQUFDO1lBQ25CaEIsdURBQVcsQ0FBQyxDQUFHO1FBQ2pCLENBQUM7OztBQXZCNkIiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vcGFnZXMvMTctMi8xNy0yLWJlZm9yZS9pbmRleC50c3g/YzQ3MSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUm91dGVyIGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IHsgQ29tcG9uZW50IH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE15Q29tcG9uZW50IGV4dGVuZHMgQ29tcG9uZW50IHtcbiAgc3RhdGUgPSB7XG4gICAgY291bnQ6IDAsXG4gIH07XG5cbiAgY29tcG9uZW50RGlkTW91bnQoKSB7XG4gICAgY29uc29sZS5sb2coXCLsu7Ttj6zrhIztirjqsIAg66eI7Jq07Yq465CQ7Iq164uI64ukflwiKTtcbiAgfVxuXG4gIGNvbXBvbmVudERpZFVwZGF0ZSgpIHtcbiAgICBjb25zb2xlLmxvZyhcIuy7tO2PrOuEjO2KuOqwgCDrs4Dqsr3rkJDsirXri4jri6R+XCIpO1xuICB9XG5cbiAgY29tcG9uZW50V2lsbFVubW91bnQoKSB7XG4gICAgYWxlcnQoXCLsu7Ttj6zrhIztirjqsIAg7KCc6rGw65Cp64uI64ukflwiKTtcbiAgfVxuXG4gIG9uQ2xpY2tDb3VudGVyID0gKCkgPT4ge1xuICAgIHRoaXMuc2V0U3RhdGUoKHByZXY6IHsgY291bnQ6IG51bWJlciB9KSA9PiAoeyBjb3VudDogcHJldi5jb3VudCArIDEgfSkpO1xuICB9O1xuXG4gIG9uQ2xpY2tNb3ZlID0gKCkgPT4ge1xuICAgIFJvdXRlci5wdXNoKFwiL1wiKTtcbiAgfTtcblxuICByZW5kZXIoKSB7XG4gICAgY29uc29sZS5sb2coXCLrp4jsmrTtirgg7Iuc7J6RXCIpO1xuICAgIHJldHVybiAoXG4gICAgICA8PlxuICAgICAgICA8ZGl2Puy5tOyatO2KuDoge3RoaXMuc3RhdGUuY291bnR9PC9kaXY+XG4gICAgICAgIDxidXR0b24gb25DbGljaz17dGhpcy5vbkNsaWNrQ291bnRlcn0+7Lm07Jq07Yq4KCsxKTwvYnV0dG9uPlxuICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e3RoaXMub25DbGlja01vdmV9PuydtOuPme2VmOq4sDwvYnV0dG9uPlxuICAgICAgPC8+XG4gICAgKTtcbiAgfVxufVxuIl0sIm5hbWVzIjpbIlJvdXRlciIsIkNvbXBvbmVudCIsIk15Q29tcG9uZW50IiwiY29tcG9uZW50RGlkTW91bnQiLCJjb25zb2xlIiwibG9nIiwiY29tcG9uZW50RGlkVXBkYXRlIiwiY29tcG9uZW50V2lsbFVubW91bnQiLCJhbGVydCIsInJlbmRlciIsImRpdiIsInN0YXRlIiwiY291bnQiLCJidXR0b24iLCJvbkNsaWNrIiwib25DbGlja0NvdW50ZXIiLCJvbkNsaWNrTW92ZSIsInNldFN0YXRlIiwicHJldiIsInB1c2giXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/17-2/17-2-before/index.tsx\n");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/17-2/17-2-before/index.tsx"));
module.exports = __webpack_exports__;

})();