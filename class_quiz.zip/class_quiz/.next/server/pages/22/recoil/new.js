"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/22/recoil/new";
exports.ids = ["pages/22/recoil/new"];
exports.modules = {

/***/ "./pages/22/recoil/new/index.tsx":
/*!***************************************!*\
  !*** ./pages/22/recoil/new/index.tsx ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ NewPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _src_components_units_22_write__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../src/components/units/22/write */ \"./src/components/units/22/write/index.tsx\");\n/* harmony import */ var _src_commons_library_recoil__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../src/commons/library/recoil */ \"./src/commons/library/recoil/index.tsx\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\nfunction NewPage() {\n    const [isEdit, setIsEdit] = (0,recoil__WEBPACK_IMPORTED_MODULE_4__.useRecoilState)(_src_commons_library_recoil__WEBPACK_IMPORTED_MODULE_3__.isEditState);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        setIsEdit(false);\n    }, []);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_components_units_22_write__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/22/recoil/new/index.tsx\",\n        lineNumber: 13,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMi9yZWNvaWwvbmV3L2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBQTJDO0FBQ3NCO0FBQ0c7QUFDN0I7QUFFeEIsUUFBUSxDQUFDSSxPQUFPLEdBQUcsQ0FBQztJQUNqQyxLQUFLLEVBQUVDLE1BQU0sRUFBRUMsU0FBUyxJQUFJSCxzREFBYyxDQUFDRCxvRUFBVztJQUV0REYsZ0RBQVMsS0FBTyxDQUFDO1FBQ2ZNLFNBQVMsQ0FBQyxLQUFLO0lBQ2pCLENBQUMsRUFBRSxDQUFDLENBQUM7SUFFTCxNQUFNLDZFQUFFTCxzRUFBUzs7Ozs7QUFDbkIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9wYWdlcy8yMi9yZWNvaWwvbmV3L2luZGV4LnRzeD83ZDhiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBXcml0ZVBhZ2UgZnJvbSBcIi4uLy4uLy4uLy4uL3NyYy9jb21wb25lbnRzL3VuaXRzLzIyL3dyaXRlXCI7XG5pbXBvcnQgeyBpc0VkaXRTdGF0ZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9zcmMvY29tbW9ucy9saWJyYXJ5L3JlY29pbFwiO1xuaW1wb3J0IHsgdXNlUmVjb2lsU3RhdGUgfSBmcm9tIFwicmVjb2lsXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE5ld1BhZ2UoKSB7XG4gIGNvbnN0IFtpc0VkaXQsIHNldElzRWRpdF0gPSB1c2VSZWNvaWxTdGF0ZShpc0VkaXRTdGF0ZSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzZXRJc0VkaXQoZmFsc2UpO1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIDxXcml0ZVBhZ2UgLz47XG59XG4iXSwibmFtZXMiOlsidXNlRWZmZWN0IiwiV3JpdGVQYWdlIiwiaXNFZGl0U3RhdGUiLCJ1c2VSZWNvaWxTdGF0ZSIsIk5ld1BhZ2UiLCJpc0VkaXQiLCJzZXRJc0VkaXQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/22/recoil/new/index.tsx\n");

/***/ }),

/***/ "./src/commons/library/recoil/index.tsx":
/*!**********************************************!*\
  !*** ./src/commons/library/recoil/index.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"isEditState\": () => (/* binding */ isEditState)\n/* harmony export */ });\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_0__);\n\nconst isEditState = (0,recoil__WEBPACK_IMPORTED_MODULE_0__.atom)({\n    key: \"isEditState\",\n    default: true\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9saWJyYXJ5L3JlY29pbC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQTZCO0FBRXRCLEtBQUssQ0FBQ0MsV0FBVyxHQUFHRCw0Q0FBSSxDQUFDLENBQUM7SUFDL0JFLEdBQUcsRUFBRSxDQUFhO0lBQ2xCQyxPQUFPLEVBQUUsSUFBSTtBQUNmLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vc3JjL2NvbW1vbnMvbGlicmFyeS9yZWNvaWwvaW5kZXgudHN4PzAwOTAiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXRvbSB9IGZyb20gXCJyZWNvaWxcIjtcblxuZXhwb3J0IGNvbnN0IGlzRWRpdFN0YXRlID0gYXRvbSh7XG4gIGtleTogXCJpc0VkaXRTdGF0ZVwiLFxuICBkZWZhdWx0OiB0cnVlLFxufSk7XG4iXSwibmFtZXMiOlsiYXRvbSIsImlzRWRpdFN0YXRlIiwia2V5IiwiZGVmYXVsdCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/library/recoil/index.tsx\n");

/***/ }),

/***/ "./src/components/units/22/write/index.tsx":
/*!*************************************************!*\
  !*** ./src/components/units/22/write/index.tsx ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ WritePage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _commons_library_recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../commons/library/recoil */ \"./src/commons/library/recoil/index.tsx\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction WritePage() {\n    const [isEdit, setIsEdit] = (0,recoil__WEBPACK_IMPORTED_MODULE_2__.useRecoilState)(_commons_library_recoil__WEBPACK_IMPORTED_MODULE_1__.isEditState);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n            children: isEdit ? \"수정하기\" : \"등록하기\"\n        }, void 0, false, {\n            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/22/write/index.tsx\",\n            lineNumber: 10,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/22/write/index.tsx\",\n        lineNumber: 9,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy8yMi93cml0ZS9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUNnRTtBQUN6QjtBQUV4QixRQUFRLENBQUNFLFNBQVMsR0FBRyxDQUFDO0lBQ25DLEtBQUssRUFBRUMsTUFBTSxFQUFFQyxTQUFTLElBQUlILHNEQUFjLENBQUNELGdFQUFXO0lBRXRELE1BQU0sNkVBQ0hLLENBQUc7OEZBQ0RDLENBQUU7c0JBQUVILE1BQU0sR0FBRyxDQUFNOzs7Ozs7Ozs7OztBQUdsQixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3NyYy9jb21wb25lbnRzL3VuaXRzLzIyL3dyaXRlL2luZGV4LnRzeD80OWIyIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBpc0VkaXRTdGF0ZSB9IGZyb20gXCIuLi8uLi8uLi8uLi9jb21tb25zL2xpYnJhcnkvcmVjb2lsXCI7XG5pbXBvcnQgeyB1c2VSZWNvaWxTdGF0ZSB9IGZyb20gXCJyZWNvaWxcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gV3JpdGVQYWdlKCkge1xuICBjb25zdCBbaXNFZGl0LCBzZXRJc0VkaXRdID0gdXNlUmVjb2lsU3RhdGUoaXNFZGl0U3RhdGUpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMT57aXNFZGl0ID8gXCLsiJjsoJXtlZjquLBcIiA6IFwi65Ox66Gd7ZWY6riwXCJ9PC9oMT5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJpc0VkaXRTdGF0ZSIsInVzZVJlY29pbFN0YXRlIiwiV3JpdGVQYWdlIiwiaXNFZGl0Iiwic2V0SXNFZGl0IiwiZGl2IiwiaDEiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/units/22/write/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("recoil");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/22/recoil/new/index.tsx"));
module.exports = __webpack_exports__;

})();