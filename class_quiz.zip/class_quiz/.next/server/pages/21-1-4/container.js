"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/21-1-4/container";
exports.ids = ["pages/21-1-4/container"];
exports.modules = {

/***/ "./pages/21-1-4/container/index.tsx":
/*!******************************************!*\
  !*** ./pages/21-1-4/container/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Container)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n\n\nfunction Container() {\n    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);\n    const onClickCounter = ()=>{\n        setState((qwer)=>qwer + 1\n        );\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: state\n            }, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/21-1-4/container/index.tsx\",\n                lineNumber: 12,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"button\", {\n                onClick: onClickCounter,\n                children: \"클릭!\"\n            }, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/21-1-4/container/index.tsx\",\n                lineNumber: 13,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/21-1-4/container/index.tsx\",\n        lineNumber: 11,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMS0xLTQvY29udGFpbmVyL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBZ0M7QUFFakIsUUFBUSxDQUFDQyxTQUFTLEdBQWdCLENBQUM7SUFDaEQsS0FBSyxNQUFFQyxLQUFLLE1BQUVDLFFBQVEsTUFBSUgsK0NBQVEsQ0FBQyxDQUFDO0lBRXBDLEtBQUssQ0FBQ0ksY0FBYyxPQUFTLENBQUM7UUFDNUJELFFBQVEsRUFBRUUsSUFBSSxHQUFLQSxJQUFJLEdBQUcsQ0FBQzs7SUFDN0IsQ0FBQztJQUVELE1BQU0sNkVBQ0hDLENBQUc7O3dGQUNEQSxDQUFHOzBCQUFFSixLQUFLOzs7Ozs7d0ZBQ1ZLLENBQU07Z0JBQUNDLE9BQU8sRUFBRUosY0FBYzswQkFBRSxDQUFHOzs7Ozs7Ozs7Ozs7QUFHMUMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9wYWdlcy8yMS0xLTQvY29udGFpbmVyL2luZGV4LnRzeD9kNmJiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnRhaW5lcigpOiBKU1guRWxlbWVudCB7XG4gIGNvbnN0IFtzdGF0ZSwgc2V0U3RhdGVdID0gdXNlU3RhdGUoMCk7XG5cbiAgY29uc3Qgb25DbGlja0NvdW50ZXIgPSAoKSA9PiB7XG4gICAgc2V0U3RhdGUoKHF3ZXIpID0+IHF3ZXIgKyAxKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXY+XG4gICAgICA8ZGl2PntzdGF0ZX08L2Rpdj5cbiAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja0NvdW50ZXJ9Pu2BtOumrSE8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRhaW5lciIsInN0YXRlIiwic2V0U3RhdGUiLCJvbkNsaWNrQ291bnRlciIsInF3ZXIiLCJkaXYiLCJidXR0b24iLCJvbkNsaWNrIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/21-1-4/container/index.tsx\n");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/21-1-4/container/index.tsx"));
module.exports = __webpack_exports__;

})();