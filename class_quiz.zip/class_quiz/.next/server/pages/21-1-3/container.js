"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/21-1-3/container";
exports.ids = ["pages/21-1-3/container"];
exports.modules = {

/***/ "./pages/21-1-3/container/index.tsx":
/*!******************************************!*\
  !*** ./pages/21-1-3/container/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Container)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction Container() {\n    [\n        \"철수\",\n        \"영희\",\n        \"훈이\",\n        \"맹구\"\n    ].map((index)=>{\n        console.log(`${el}는 ${index}번째 칸에 들어있습니다.`);\n    });\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMS0xLTMvY29udGFpbmVyL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQWUsUUFBUSxDQUFDQSxTQUFTLEdBQWdCLENBQUM7SUFDaEQsQ0FBQztRQUFBLENBQUk7UUFBTSxDQUFJO1FBQU0sQ0FBSTtRQUFNLENBQUk7SUFBSSxDQUFDLENBQUNDLEdBQUcsRUFBRUMsS0FBSyxHQUFLLENBQUM7UUFDdkNDLE9BQVQsQ0FBQ0MsR0FBRyxJQUFJQyxFQUFFLENBQUMsSUFBRSxFQUFJSCxLQUFLLENBQUM7SUFDOUIsQ0FBQztJQUVELE1BQU07QUFDUixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3BhZ2VzLzIxLTEtMy9jb250YWluZXIvaW5kZXgudHN4P2UwYmEiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ29udGFpbmVyKCk6IEpTWC5FbGVtZW50IHtcbiAgW1wi7LKg7IiYXCIsIFwi7JiB7Z2sXCIsIFwi7ZuI7J20XCIsIFwi66e56rWsXCJdLm1hcCgoaW5kZXgpID0+IHtcbiAgICBjb25zb2xlLmxvZyhgJHtlbH3ripQgJHtpbmRleH3rsojsp7gg7Lm47JeQIOuTpOyWtOyeiOyKteuLiOuLpC5gKTtcbiAgfSk7XG5cbiAgcmV0dXJuIDw+PC8+O1xufVxuIl0sIm5hbWVzIjpbIkNvbnRhaW5lciIsIm1hcCIsImluZGV4IiwiY29uc29sZSIsImxvZyIsImVsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/21-1-3/container/index.tsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/21-1-3/container/index.tsx"));
module.exports = __webpack_exports__;

})();