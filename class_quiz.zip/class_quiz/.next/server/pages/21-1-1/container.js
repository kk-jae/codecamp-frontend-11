"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/21-1-1/container";
exports.ids = ["pages/21-1-1/container"];
exports.modules = {

/***/ "./pages/21-1-1/container/index.tsx":
/*!******************************************!*\
  !*** ./pages/21-1-1/container/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Container)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _presenter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../presenter */ \"./pages/21-1-1/presenter/index.tsx\");\n\n\nfunction Container() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_presenter__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n            child: \"철수\"\n        }, void 0, false, {\n            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/21-1-1/container/index.tsx\",\n            lineNumber: 6,\n            columnNumber: 7\n        }, this)\n    }, void 0, false));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMS0xLTEvY29udGFpbmVyL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFvQztBQUVyQixRQUFRLENBQUNDLFNBQVMsR0FBZ0IsQ0FBQztJQUNoRCxNQUFNOzhGQUVERCxrREFBUztZQUFDRSxLQUFLLEVBQUMsQ0FBSTs7Ozs7OztBQUczQixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3BhZ2VzLzIxLTEtMS9jb250YWluZXIvaW5kZXgudHN4PzlkZDkiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFByZXNlbnRlciBmcm9tIFwiLi4vcHJlc2VudGVyXCI7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvbnRhaW5lcigpOiBKU1guRWxlbWVudCB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxQcmVzZW50ZXIgY2hpbGQ9XCLssqDsiJhcIiAvPlxuICAgIDwvPlxuICApO1xufVxuIl0sIm5hbWVzIjpbIlByZXNlbnRlciIsIkNvbnRhaW5lciIsImNoaWxkIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/21-1-1/container/index.tsx\n");

/***/ }),

/***/ "./pages/21-1-1/presenter/index.tsx":
/*!******************************************!*\
  !*** ./pages/21-1-1/presenter/index.tsx ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Presenter)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n\nfunction Presenter(props) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: props.child\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/21-1-1/presenter/index.tsx\",\n        lineNumber: 2,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8yMS0xLTEvcHJlc2VudGVyL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQWUsUUFBUSxDQUFDQSxTQUFTLENBQUNDLEtBQVUsRUFBZSxDQUFDO0lBQzFELE1BQU0sNkVBQUVDLENBQUc7a0JBQUVELEtBQUssQ0FBQ0UsS0FBSzs7Ozs7O0FBQzFCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vcGFnZXMvMjEtMS0xL3ByZXNlbnRlci9pbmRleC50c3g/Nzg3YSJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcmVzZW50ZXIocHJvcHM6IGFueSk6IEpTWC5FbGVtZW50IHtcbiAgcmV0dXJuIDxkaXY+e3Byb3BzLmNoaWxkfTwvZGl2Pjtcbn1cbiJdLCJuYW1lcyI6WyJQcmVzZW50ZXIiLCJwcm9wcyIsImRpdiIsImNoaWxkIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/21-1-1/presenter/index.tsx\n");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/21-1-1/container/index.tsx"));
module.exports = __webpack_exports__;

})();