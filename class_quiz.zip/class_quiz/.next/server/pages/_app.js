/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _src_components_units_product_layout_index__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../src/components/units/product/layout/index */ \"./src/components/units/product/layout/index.tsx\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _src_commons_styles_globalStyles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../src/commons/styles/globalStyles */ \"./src/commons/styles/globalStyles.ts\");\n/* harmony import */ var _src_commons_apollo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../src/commons/apollo */ \"./src/commons/apollo/index.tsx\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! recoil */ \"recoil\");\n/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(recoil__WEBPACK_IMPORTED_MODULE_5__);\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_commons_apollo__WEBPACK_IMPORTED_MODULE_4__]);\n_src_commons_apollo__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\n\n// graphql API를 위한 초기 설치\n// InMemoryCache는 cache 저장을 위한 코드입니다\nfunction App({ Component  }) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(recoil__WEBPACK_IMPORTED_MODULE_5__.RecoilRoot, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_commons_apollo__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_emotion_react__WEBPACK_IMPORTED_MODULE_2__.Global, {\n                        styles: _src_commons_styles_globalStyles__WEBPACK_IMPORTED_MODULE_3__.globalStyles\n                    }, void 0, false, {\n                        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/_app.tsx\",\n                        lineNumber: 18,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_components_units_product_layout_index__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {}, void 0, false, {\n                            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/_app.tsx\",\n                            lineNumber: 20,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/_app.tsx\",\n                        lineNumber: 19,\n                        columnNumber: 11\n                    }, this)\n                ]\n            }, void 0, true)\n        }, void 0, false, {\n            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/_app.tsx\",\n            lineNumber: 16,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/_app.tsx\",\n        lineNumber: 15,\n        columnNumber: 5\n    }, this));\n};\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUdpRTtBQUMxQjtBQUMwQjtBQUNoQjtBQUNkO0FBRW5DLEVBQXdCO0FBQ1YsRUFBc0I7QUFFckIsUUFBUSxDQUFDSyxHQUFHLENBQUMsQ0FBQyxDQUFDQyxTQUFTLEVBQVcsQ0FBQyxFQUFlLENBQUM7SUFDakUsTUFBTSw2RUFDSEYsOENBQVU7OEZBQ1JELDJEQUFhOzs7Z0dBRVRGLGtEQUFNO3dCQUFDTSxNQUFNLEVBQUVMLDBFQUFZOzs7Ozs7Z0dBQzNCRixrRkFBTTs4R0FDSk0sU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQU10QixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3BhZ2VzL19hcHAudHN4PzJmYmUiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnXG5cbmltcG9ydCB0eXBlIHsgQXBwUHJvcHMgfSBmcm9tIFwibmV4dC9hcHBcIjtcbmltcG9ydCBMYXlvdXQgZnJvbSBcIi4uL3NyYy9jb21wb25lbnRzL3VuaXRzL3Byb2R1Y3QvbGF5b3V0L2luZGV4XCI7XG5pbXBvcnQgeyBHbG9iYWwgfSBmcm9tIFwiQGVtb3Rpb24vcmVhY3RcIjtcbmltcG9ydCB7IGdsb2JhbFN0eWxlcyB9IGZyb20gXCIuLi9zcmMvY29tbW9ucy9zdHlsZXMvZ2xvYmFsU3R5bGVzXCI7XG5pbXBvcnQgQXBvbGxvU2V0dGluZyBmcm9tIFwiLi4vc3JjL2NvbW1vbnMvYXBvbGxvXCI7XG5pbXBvcnQgeyBSZWNvaWxSb290IH0gZnJvbSBcInJlY29pbFwiO1xuXG4vLyBncmFwaHFsIEFQSeulvCDsnITtlZwg7LSI6riwIOyEpOy5mFxuLy8gSW5NZW1vcnlDYWNoZeuKlCBjYWNoZSDsoIDsnqXsnYQg7JyE7ZWcIOy9lOuTnOyeheuLiOuLpFxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoeyBDb21wb25lbnQgfTogQXBwUHJvcHMpOiBKU1guRWxlbWVudCB7XG4gIHJldHVybiAoXG4gICAgPFJlY29pbFJvb3Q+XG4gICAgICA8QXBvbGxvU2V0dGluZz5cbiAgICAgICAgPD5cbiAgICAgICAgICA8R2xvYmFsIHN0eWxlcz17Z2xvYmFsU3R5bGVzfSAvPlxuICAgICAgICAgIDxMYXlvdXQ+XG4gICAgICAgICAgICA8Q29tcG9uZW50IC8+XG4gICAgICAgICAgPC9MYXlvdXQ+XG4gICAgICAgIDwvPlxuICAgICAgPC9BcG9sbG9TZXR0aW5nPlxuICAgIDwvUmVjb2lsUm9vdD5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJMYXlvdXQiLCJHbG9iYWwiLCJnbG9iYWxTdHlsZXMiLCJBcG9sbG9TZXR0aW5nIiwiUmVjb2lsUm9vdCIsIkFwcCIsIkNvbXBvbmVudCIsInN0eWxlcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./src/commons/apollo/index.tsx":
/*!**************************************!*\
  !*** ./src/commons/apollo/index.tsx ***!
  \**************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ ApolloSetting)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var apollo_upload_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! apollo-upload-client */ \"apollo-upload-client\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apollo_upload_client__WEBPACK_IMPORTED_MODULE_2__]);\napollo_upload_client__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\nfunction ApolloSetting(props) {\n    const uploadLink = (0,apollo_upload_client__WEBPACK_IMPORTED_MODULE_2__.createUploadLink)({\n        uri: \"http://backend-practice.codebootcamp.co.kr/graphql\"\n    });\n    const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_1__.ApolloClient({\n        link: _apollo_client__WEBPACK_IMPORTED_MODULE_1__.ApolloLink.from([\n            uploadLink\n        ]),\n        cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_1__.InMemoryCache()\n    });\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_apollo_client__WEBPACK_IMPORTED_MODULE_1__.ApolloProvider, {\n        client: client,\n        children: props.children\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/commons/apollo/index.tsx\",\n        lineNumber: 22,\n        columnNumber: 10\n    }, this));\n};\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9hcG9sbG8vaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFLdUI7QUFDZ0M7QUFLeEMsUUFBUSxDQUFDSyxhQUFhLENBQUNDLEtBQTBCLEVBQWUsQ0FBQztJQUM5RSxLQUFLLENBQUNDLFVBQVUsR0FBR0gsc0VBQWdCLENBQUMsQ0FBQztRQUNuQ0ksR0FBRyxFQUFFLENBQW9EO0lBQzNELENBQUM7SUFFRCxLQUFLLENBQUNDLE1BQU0sR0FBRyxHQUFHLENBQUNULHdEQUFZLENBQUMsQ0FBQztRQUMvQlUsSUFBSSxFQUFFUCwyREFBZSxDQUFDLENBQUNJO1lBQUFBLFVBQVU7UUFBQSxDQUFDO1FBQ2xDSyxLQUFLLEVBQUUsR0FBRyxDQUFDWCx5REFBYTtJQUMxQixDQUFDO0lBRUQsTUFBTSw2RUFBRUMsMERBQWM7UUFBQ08sTUFBTSxFQUFFQSxNQUFNO2tCQUFHSCxLQUFLLENBQUNPLFFBQVE7Ozs7OztBQUN4RCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3NfcXVpei8uL3NyYy9jb21tb25zL2Fwb2xsby9pbmRleC50c3g/YzM5OCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBcG9sbG9DbGllbnQsXG4gIEluTWVtb3J5Q2FjaGUsXG4gIEFwb2xsb1Byb3ZpZGVyLFxuICBBcG9sbG9MaW5rLFxufSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcbmltcG9ydCB7IGNyZWF0ZVVwbG9hZExpbmsgfSBmcm9tIFwiYXBvbGxvLXVwbG9hZC1jbGllbnRcIjtcblxuaW50ZXJmYWNlIElBcG9sbG9TZXR0aW5nUHJvcHMge1xuICBjaGlsZHJlbjogSlNYLkVsZW1lbnQ7XG59XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcG9sbG9TZXR0aW5nKHByb3BzOiBJQXBvbGxvU2V0dGluZ1Byb3BzKTogSlNYLkVsZW1lbnQge1xuICBjb25zdCB1cGxvYWRMaW5rID0gY3JlYXRlVXBsb2FkTGluayh7XG4gICAgdXJpOiBcImh0dHA6Ly9iYWNrZW5kLXByYWN0aWNlLmNvZGVib290Y2FtcC5jby5rci9ncmFwaHFsXCIsIC8vIDE167aA7YSwIOyggeyaqVxuICB9KTtcblxuICBjb25zdCBjbGllbnQgPSBuZXcgQXBvbGxvQ2xpZW50KHtcbiAgICBsaW5rOiBBcG9sbG9MaW5rLmZyb20oW3VwbG9hZExpbmtdKSxcbiAgICBjYWNoZTogbmV3IEluTWVtb3J5Q2FjaGUoKSxcbiAgfSk7XG5cbiAgcmV0dXJuIDxBcG9sbG9Qcm92aWRlciBjbGllbnQ9e2NsaWVudH0+e3Byb3BzLmNoaWxkcmVufTwvQXBvbGxvUHJvdmlkZXI+O1xufVxuIl0sIm5hbWVzIjpbIkFwb2xsb0NsaWVudCIsIkluTWVtb3J5Q2FjaGUiLCJBcG9sbG9Qcm92aWRlciIsIkFwb2xsb0xpbmsiLCJjcmVhdGVVcGxvYWRMaW5rIiwiQXBvbGxvU2V0dGluZyIsInByb3BzIiwidXBsb2FkTGluayIsInVyaSIsImNsaWVudCIsImxpbmsiLCJmcm9tIiwiY2FjaGUiLCJjaGlsZHJlbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/apollo/index.tsx\n");

/***/ }),

/***/ "./src/commons/styles/globalStyles.ts":
/*!********************************************!*\
  !*** ./src/commons/styles/globalStyles.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"globalStyles\": () => (/* binding */ globalStyles)\n/* harmony export */ });\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_0__);\n\nconst globalStyles = _emotion_react__WEBPACK_IMPORTED_MODULE_0__.css`\n  * {\n    font-size: 30px;\n    box-sizing: border-box;\n    font-family: \"myfont\";\n  }\n\n  @font-face {\n    font-family: \"myfont\";\n    src: url(\"/font/scifibit.ttf\");\n  }\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tbW9ucy9zdHlsZXMvZ2xvYmFsU3R5bGVzLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFvQztBQUU3QixLQUFLLENBQUNDLFlBQVksR0FBR0QsK0NBQUcsQ0FBQzs7Ozs7Ozs7Ozs7QUFXaEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vc3JjL2NvbW1vbnMvc3R5bGVzL2dsb2JhbFN0eWxlcy50cz9jNzc1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNzcyB9IGZyb20gXCJAZW1vdGlvbi9yZWFjdFwiO1xuXG5leHBvcnQgY29uc3QgZ2xvYmFsU3R5bGVzID0gY3NzYFxuICAqIHtcbiAgICBmb250LXNpemU6IDMwcHg7XG4gICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgICBmb250LWZhbWlseTogXCJteWZvbnRcIjtcbiAgfVxuXG4gIEBmb250LWZhY2Uge1xuICAgIGZvbnQtZmFtaWx5OiBcIm15Zm9udFwiO1xuICAgIHNyYzogdXJsKFwiL2ZvbnQvc2NpZmliaXQudHRmXCIpO1xuICB9XG5gO1xuIl0sIm5hbWVzIjpbImNzcyIsImdsb2JhbFN0eWxlcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/commons/styles/globalStyles.ts\n");

/***/ }),

/***/ "./src/components/units/product/layout/banner/index.tsx":
/*!**************************************************************!*\
  !*** ./src/components/units/product/layout/banner/index.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutBanner)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ \"./node_modules/slick-carousel/slick/slick.css\");\n/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ \"./node_modules/slick-carousel/slick/slick-theme.css\");\n/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-slick */ \"react-slick\");\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_5__);\n\n\n\n\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 10%;\n  background-color: pink;\n  padding: 0px 35% 0px 35%;\n`;\nconst H3 = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  display: flex;\n  flex-direction: row;\n  justify-content: center;\n`;\nconst IMG = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`\n  object-fit: cover;\n`;\nfunction LayoutBanner() {\n    const settings = {\n        dots: true,\n        infinite: true,\n        speed: 1000,\n        slidesToShow: 1,\n        slidesToScroll: 1,\n        autoplay: true,\n        autoplaySpeed: 3000\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_slick__WEBPACK_IMPORTED_MODULE_5___default()), {\n            ...settings,\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(H3, {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(IMG, {\n                            src: \"/배경\"\n                        }, void 0, false, {\n                            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/banner/index.tsx\",\n                            lineNumber: 40,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/banner/index.tsx\",\n                        lineNumber: 39,\n                        columnNumber: 11\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/banner/index.tsx\",\n                    lineNumber: 38,\n                    columnNumber: 9\n                }, this),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                    children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(H3, {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(IMG, {\n                            src: \"/dog.jpeg\"\n                        }, void 0, false, {\n                            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/banner/index.tsx\",\n                            lineNumber: 45,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/banner/index.tsx\",\n                        lineNumber: 44,\n                        columnNumber: 11\n                    }, this)\n                }, void 0, false, {\n                    fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/banner/index.tsx\",\n                    lineNumber: 43,\n                    columnNumber: 9\n                }, this)\n            ]\n        }, void 0, true, {\n            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/banner/index.tsx\",\n            lineNumber: 37,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/banner/index.tsx\",\n        lineNumber: 36,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9iYW5uZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQW9DO0FBQ0k7QUFDRDtBQUNNO0FBQ2I7QUFFaEMsS0FBSyxDQUFDRyxPQUFPLEdBQUdILDREQUFVLENBQUM7Ozs7QUFJM0I7QUFDQSxLQUFLLENBQUNLLEVBQUUsR0FBR0wsNERBQVUsQ0FBQzs7OztBQUl0QjtBQUVBLEtBQUssQ0FBQ00sR0FBRyxHQUFHTiw0REFBVSxDQUFDOztBQUV2QjtBQUVlLFFBQVEsQ0FBQ1EsWUFBWSxHQUFnQixDQUFDO0lBQ25ELEtBQUssQ0FBQ0MsUUFBUSxHQUFHLENBQUM7UUFDaEJDLElBQUksRUFBRSxJQUFJO1FBQ1ZDLFFBQVEsRUFBRSxJQUFJO1FBQ2RDLEtBQUssRUFBRSxJQUFJO1FBQ1hDLFlBQVksRUFBRSxDQUFDO1FBQ2ZDLGNBQWMsRUFBRSxDQUFDO1FBQ2pCQyxRQUFRLEVBQUUsSUFBSTtRQUNkQyxhQUFhLEVBQUUsSUFBSTtJQUdyQixDQUFDO0lBRUQsTUFBTSw2RUFDSGIsT0FBTzs4RkFDTEQsb0RBQU07ZUFBS08sUUFBUTs7NEZBQ2pCTCxDQUFHOzBHQUNEQyxFQUFFOzhHQUNBQyxHQUFHOzRCQUFDVyxHQUFHLEVBQUMsQ0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs0RkFHakJiLENBQUc7MEdBQ0RDLEVBQUU7OEdBQ0FDLEdBQUc7NEJBQUNXLEdBQUcsRUFBQyxDQUFXOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFNaEMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9iYW5uZXIvaW5kZXgudHN4PzM0NTYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XG5pbXBvcnQgUmVhY3QsIHsgQ29tcG9uZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay5jc3NcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLXRoZW1lLmNzc1wiO1xuaW1wb3J0IFNsaWRlciBmcm9tIFwicmVhY3Qtc2xpY2tcIjtcblxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIGhlaWdodDogMTAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBwaW5rO1xuICBwYWRkaW5nOiAwcHggMzUlIDBweCAzNSU7XG5gO1xuY29uc3QgSDMgPSBzdHlsZWQuZGl2YFxuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbmA7XG5cbmNvbnN0IElNRyA9IHN0eWxlZC5pbWdgXG4gIG9iamVjdC1maXQ6IGNvdmVyO1xuYDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0QmFubmVyKCk6IEpTWC5FbGVtZW50IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSB7XG4gICAgZG90czogdHJ1ZSxcbiAgICBpbmZpbml0ZTogdHJ1ZSxcbiAgICBzcGVlZDogMTAwMCxcbiAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgc2xpZGVzVG9TY3JvbGw6IDEsXG4gICAgYXV0b3BsYXk6IHRydWUsXG4gICAgYXV0b3BsYXlTcGVlZDogMzAwMCxcbiAgICAvLyBjZW50ZXJNb2RlOiB0cnVlLFxuICAgIC8vIGNlbnRlclBhZGRpbmc6IFwiMHB4XCIsXG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8V3JhcHBlcj5cbiAgICAgIDxTbGlkZXIgey4uLnNldHRpbmdzfT5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8SDM+XG4gICAgICAgICAgICA8SU1HIHNyYz1cIi/rsLDqsr1cIiAvPlxuICAgICAgICAgIDwvSDM+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxIMz5cbiAgICAgICAgICAgIDxJTUcgc3JjPVwiL2RvZy5qcGVnXCIgLz5cbiAgICAgICAgICA8L0gzPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvU2xpZGVyPlxuICAgIDwvV3JhcHBlcj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJSZWFjdCIsIlNsaWRlciIsIldyYXBwZXIiLCJkaXYiLCJIMyIsIklNRyIsImltZyIsIkxheW91dEJhbm5lciIsInNldHRpbmdzIiwiZG90cyIsImluZmluaXRlIiwic3BlZWQiLCJzbGlkZXNUb1Nob3ciLCJzbGlkZXNUb1Njcm9sbCIsImF1dG9wbGF5IiwiYXV0b3BsYXlTcGVlZCIsInNyYyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/units/product/layout/banner/index.tsx\n");

/***/ }),

/***/ "./src/components/units/product/layout/body/index.tsx":
/*!************************************************************!*\
  !*** ./src/components/units/product/layout/body/index.tsx ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutBody)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 40%;\n  width: 70%;\n`;\nfunction LayoutBody(props) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: props.children\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/body/index.tsx\",\n        lineNumber: 13,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9ib2R5L2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBb0M7QUFFcEMsS0FBSyxDQUFDQyxPQUFPLEdBQUdELDREQUFVLENBQUM7OztBQUczQjtBQU1lLFFBQVEsQ0FBQ0csVUFBVSxDQUFDQyxLQUF1QixFQUFFLENBQUM7SUFDM0QsTUFBTSw2RUFBRUgsT0FBTztrQkFBRUcsS0FBSyxDQUFDQyxRQUFROzs7Ozs7QUFDakMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9ib2R5L2luZGV4LnRzeD80MDJhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xuXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgaGVpZ2h0OiA0MCU7XG4gIHdpZHRoOiA3MCU7XG5gO1xuXG5pbnRlcmZhY2UgSVByb3BzTGF5b3V0Qm9keSB7XG4gIGNoaWxkcmVuOiBKU1guRWxlbWVudDtcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0Qm9keShwcm9wczogSVByb3BzTGF5b3V0Qm9keSkge1xuICByZXR1cm4gPFdyYXBwZXI+e3Byb3BzLmNoaWxkcmVufTwvV3JhcHBlcj47XG59XG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIkxheW91dEJvZHkiLCJwcm9wcyIsImNoaWxkcmVuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/units/product/layout/body/index.tsx\n");

/***/ }),

/***/ "./src/components/units/product/layout/footer/index.tsx":
/*!**************************************************************!*\
  !*** ./src/components/units/product/layout/footer/index.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutFooter)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 10%;\n  background-color: green;\n`;\nfunction LayoutFooter() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"푸터 영역\"\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/footer/index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9mb290ZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUVwQyxLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7O0FBRzNCO0FBRWUsUUFBUSxDQUFDRyxZQUFZLEdBQWdCLENBQUM7SUFDbkQsTUFBTSw2RUFBRUYsT0FBTztrQkFBQyxDQUFLOzs7Ozs7QUFDdkIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9mb290ZXIvaW5kZXgudHN4P2JkZTEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XG5cbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBoZWlnaHQ6IDEwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogZ3JlZW47XG5gO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXRGb290ZXIoKTogSlNYLkVsZW1lbnQge1xuICByZXR1cm4gPFdyYXBwZXI+7ZG47YSwIOyYgeyXrTwvV3JhcHBlcj47XG59XG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIkxheW91dEZvb3RlciJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/units/product/layout/footer/index.tsx\n");

/***/ }),

/***/ "./src/components/units/product/layout/header/index.tsx":
/*!**************************************************************!*\
  !*** ./src/components/units/product/layout/header/index.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutHeader)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 20%;\n  background-color: tomato;\n`;\nfunction LayoutHeader() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"헤더 영역\"\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/header/index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9oZWFkZXIvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUVwQyxLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7O0FBRzNCO0FBRWUsUUFBUSxDQUFDRyxZQUFZLEdBQWdCLENBQUM7SUFDbkQsTUFBTSw2RUFBRUYsT0FBTztrQkFBQyxDQUFLOzs7Ozs7QUFDdkIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9oZWFkZXIvaW5kZXgudHN4P2IxNTEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XG5cbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxuICBoZWlnaHQ6IDIwJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogdG9tYXRvO1xuYDtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0SGVhZGVyKCk6IEpTWC5FbGVtZW50IHtcbiAgcmV0dXJuIDxXcmFwcGVyPu2XpOuNlCDsmIHsl608L1dyYXBwZXI+O1xufVxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIldyYXBwZXIiLCJkaXYiLCJMYXlvdXRIZWFkZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/units/product/layout/header/index.tsx\n");

/***/ }),

/***/ "./src/components/units/product/layout/index.tsx":
/*!*******************************************************!*\
  !*** ./src/components/units/product/layout/index.tsx ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./header */ \"./src/components/units/product/layout/header/index.tsx\");\n/* harmony import */ var _banner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./banner */ \"./src/components/units/product/layout/banner/index.tsx\");\n/* harmony import */ var _body__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./body */ \"./src/components/units/product/layout/body/index.tsx\");\n/* harmony import */ var _navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./navigation */ \"./src/components/units/product/layout/navigation/index.tsx\");\n/* harmony import */ var _sidebar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./sidebar */ \"./src/components/units/product/layout/sidebar/index.tsx\");\n/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./footer */ \"./src/components/units/product/layout/footer/index.tsx\");\n\n\n\n\n\n\n\nfunction Layout(props) {\n    // console.log(props.children);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_header__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/index.tsx\",\n                lineNumber: 17,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_banner__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/index.tsx\",\n                lineNumber: 18,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_navigation__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/index.tsx\",\n                lineNumber: 19,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                style: {\n                    display: \"flex\"\n                },\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_sidebar__WEBPACK_IMPORTED_MODULE_5__[\"default\"], {}, void 0, false, {\n                        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/index.tsx\",\n                        lineNumber: 21,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_body__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                            children: props.children\n                        }, void 0, false, {\n                            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/index.tsx\",\n                            lineNumber: 23,\n                            columnNumber: 11\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/index.tsx\",\n                        lineNumber: 22,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/index.tsx\",\n                lineNumber: 20,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_footer__WEBPACK_IMPORTED_MODULE_6__[\"default\"], {}, void 0, false, {\n                fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/index.tsx\",\n                lineNumber: 26,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/index.tsx\",\n        lineNumber: 16,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUFtQztBQUNBO0FBQ0o7QUFDWTtBQUNOO0FBQ0Y7QUFPcEIsUUFBUSxDQUFDTSxNQUFNLENBQUNDLEtBQW1CLEVBQUUsQ0FBQztJQUNuRCxFQUErQjtJQUMvQixNQUFNLDZFQUNIQyxDQUFHOzt3RkFDRFIsK0NBQVk7Ozs7O3dGQUNaQywrQ0FBWTs7Ozs7d0ZBQ1pFLG1EQUFnQjs7Ozs7d0ZBQ2hCSyxDQUFHO2dCQUFDQyxLQUFLLEVBQUUsQ0FBQztvQkFBQ0MsT0FBTyxFQUFFLENBQU07Z0JBQUMsQ0FBQzs7Z0dBQzVCTixnREFBYTs7Ozs7Z0dBQ2JGLDZDQUFVOzhHQUNSTSxDQUFHO3NDQUFFRCxLQUFLLENBQUNJLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7O3dGQUd2Qk4sK0NBQVk7Ozs7Ozs7Ozs7O0FBR25CLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vc3JjL2NvbXBvbmVudHMvdW5pdHMvcHJvZHVjdC9sYXlvdXQvaW5kZXgudHN4P2EwZTMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExheW91dEhlYWRlciBmcm9tIFwiLi9oZWFkZXJcIjtcbmltcG9ydCBMYXlvdXRCYW5uZXIgZnJvbSBcIi4vYmFubmVyXCI7XG5pbXBvcnQgTGF5b3V0Qm9keSBmcm9tIFwiLi9ib2R5XCI7XG5pbXBvcnQgTGF5b3V0TmF2aWdhdGlvbiBmcm9tIFwiLi9uYXZpZ2F0aW9uXCI7XG5pbXBvcnQgTGF5b3V0U2lkZWJhciBmcm9tIFwiLi9zaWRlYmFyXCI7XG5pbXBvcnQgTGF5b3V0Rm9vdGVyIGZyb20gXCIuL2Zvb3RlclwiO1xuaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XG5cbmludGVyZmFjZSBJUHJvcHNMYXlvdXQge1xuICBjaGlsZHJlbjogSlNYLkVsZW1lbnQ7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dChwcm9wczogSVByb3BzTGF5b3V0KSB7XG4gIC8vIGNvbnNvbGUubG9nKHByb3BzLmNoaWxkcmVuKTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPExheW91dEhlYWRlciAvPlxuICAgICAgPExheW91dEJhbm5lciAvPlxuICAgICAgPExheW91dE5hdmlnYXRpb24gLz5cbiAgICAgIDxkaXYgc3R5bGU9e3sgZGlzcGxheTogXCJmbGV4XCIgfX0+XG4gICAgICAgIDxMYXlvdXRTaWRlYmFyIC8+XG4gICAgICAgIDxMYXlvdXRCb2R5PlxuICAgICAgICAgIDxkaXY+e3Byb3BzLmNoaWxkcmVufTwvZGl2PlxuICAgICAgICA8L0xheW91dEJvZHk+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxMYXlvdXRGb290ZXIgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJuYW1lcyI6WyJMYXlvdXRIZWFkZXIiLCJMYXlvdXRCYW5uZXIiLCJMYXlvdXRCb2R5IiwiTGF5b3V0TmF2aWdhdGlvbiIsIkxheW91dFNpZGViYXIiLCJMYXlvdXRGb290ZXIiLCJMYXlvdXQiLCJwcm9wcyIsImRpdiIsInN0eWxlIiwiZGlzcGxheSIsImNoaWxkcmVuIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/units/product/layout/index.tsx\n");

/***/ }),

/***/ "./src/components/units/product/layout/navigation/index.tsx":
/*!******************************************************************!*\
  !*** ./src/components/units/product/layout/navigation/index.tsx ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutNavigation)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 20%;\n  background-color: orange;\n`;\nfunction LayoutNavigation() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"네비게이션 영역\"\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/navigation/index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9uYXZpZ2F0aW9uL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBb0M7QUFFcEMsS0FBSyxDQUFDQyxPQUFPLEdBQUdELDREQUFVLENBQUM7OztBQUczQjtBQUVlLFFBQVEsQ0FBQ0csZ0JBQWdCLEdBQWdCLENBQUM7SUFDdkQsTUFBTSw2RUFBRUYsT0FBTztrQkFBQyxDQUFROzs7Ozs7QUFDMUIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9uYXZpZ2F0aW9uL2luZGV4LnRzeD9hMzI3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xuXG5jb25zdCBXcmFwcGVyID0gc3R5bGVkLmRpdmBcbiAgaGVpZ2h0OiAyMCU7XG4gIGJhY2tncm91bmQtY29sb3I6IG9yYW5nZTtcbmA7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dE5hdmlnYXRpb24oKTogSlNYLkVsZW1lbnQge1xuICByZXR1cm4gPFdyYXBwZXI+64Sk67mE6rKM7J207IWYIOyYgeyXrTwvV3JhcHBlcj47XG59XG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIkxheW91dE5hdmlnYXRpb24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/components/units/product/layout/navigation/index.tsx\n");

/***/ }),

/***/ "./src/components/units/product/layout/sidebar/index.tsx":
/*!***************************************************************!*\
  !*** ./src/components/units/product/layout/sidebar/index.tsx ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutSidebar)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  width: 30%;\n  background-color: skyblue;\n`;\nfunction LayoutSidebar() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"사이드바 영역\"\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/src/components/units/product/layout/sidebar/index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy91bml0cy9wcm9kdWN0L2xheW91dC9zaWRlYmFyL2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBb0M7QUFFcEMsS0FBSyxDQUFDQyxPQUFPLEdBQUdELDREQUFVLENBQUM7OztBQUczQjtBQUVlLFFBQVEsQ0FBQ0csYUFBYSxHQUFnQixDQUFDO0lBQ3BELE1BQU0sNkVBQUVGLE9BQU87a0JBQUMsQ0FBTzs7Ozs7O0FBQ3pCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzc19xdWl6Ly4vc3JjL2NvbXBvbmVudHMvdW5pdHMvcHJvZHVjdC9sYXlvdXQvc2lkZWJhci9pbmRleC50c3g/YTc0NiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcblxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXG4gIHdpZHRoOiAzMCU7XG4gIGJhY2tncm91bmQtY29sb3I6IHNreWJsdWU7XG5gO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXRTaWRlYmFyKCk6IEpTWC5FbGVtZW50IHtcbiAgcmV0dXJuIDxXcmFwcGVyPuyCrOydtOuTnOuwlCDsmIHsl608L1dyYXBwZXI+O1xufVxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIldyYXBwZXIiLCJkaXYiLCJMYXlvdXRTaWRlYmFyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/components/units/product/layout/sidebar/index.tsx\n");

/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick-theme.css":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick-theme.css ***!
  \***********************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick.css":
/*!*****************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick.css ***!
  \*****************************************************/
/***/ (() => {



/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/react":
/*!*********************************!*\
  !*** external "@emotion/react" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/react");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/styled");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-slick":
/*!******************************!*\
  !*** external "react-slick" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-slick");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "recoil":
/*!*************************!*\
  !*** external "recoil" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("recoil");

/***/ }),

/***/ "apollo-upload-client":
/*!***************************************!*\
  !*** external "apollo-upload-client" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = import("apollo-upload-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();