"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n\n// import '../styles/globals.css'\n\n// graphql API를 위한 초기 설치\n// InMemoryCache는 cache 저장을 위한 코드입니다\nfunction App({ Component , pageProps  }) {\n    const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_1__.ApolloClient({\n        uri: \"http://backend-example.codebootcamp.co.kr/graphql\",\n        cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_1__.InMemoryCache()\n    });\n    // graphql API를 위한 초기 설치\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_apollo_client__WEBPACK_IMPORTED_MODULE_1__.ApolloProvider, {\n        client: client,\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/_app.js\",\n            lineNumber: 16,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/home/kwon/바탕화면/codecamp-frontend-kwon/class_quiz/pages/_app.js\",\n        lineNumber: 15,\n        columnNumber: 5\n    }, this));\n}; //모든 페이지의 공통 설정들을 정리하는 곳 입니다.\n // 기본 _app.js 시작\n // // import '../styles/globals.css'\n // export default function App({ Component, pageProps }) {\n //   return <Component {...pageProps} />;\n // }\n // 기본 _app.js 종료\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBLEVBQWlDO0FBRTJDO0FBQzVFLEVBQXdCO0FBQ1YsRUFBc0I7QUFFckIsUUFBUSxDQUFDRyxHQUFHLENBQUMsQ0FBQyxDQUFDQyxTQUFTLEdBQUVDLFNBQVMsRUFBQyxDQUFDLEVBQUUsQ0FBQztJQUNyRCxLQUFLLENBQUNDLE1BQU0sR0FBRyxHQUFHLENBQUNOLHdEQUFZLENBQUMsQ0FBQztRQUMvQk8sR0FBRyxFQUFFLENBQW1EO1FBQ3hEQyxLQUFLLEVBQUUsR0FBRyxDQUFDUCx5REFBYTtJQUMxQixDQUFDO0lBQ0QsRUFBd0I7SUFFVixNQUFSLDZFQUNIQywwREFBYztRQUFDSSxNQUFNLEVBQUVBLE1BQU07OEZBQzNCRixTQUFTO2VBQUtDLFNBQVM7Ozs7Ozs7Ozs7O0FBRzlCLENBQUMsQ0FFRCxDQUE2QixFQUF3QztBQUU3QixDQUF4QixFQUFRO0FBQ2hCLENBQTRCO0FBRXBDLENBQTBEO0FBQzFELENBQXlDO0FBQ3pDLENBQUk7QUFDSixDQUFnQiIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzX3F1aXovLi9wYWdlcy9fYXBwLmpzP2UwYWQiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnXG5cbmltcG9ydCB7IEFwb2xsb0NsaWVudCwgSW5NZW1vcnlDYWNoZSwgQXBvbGxvUHJvdmlkZXIgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcbi8vIGdyYXBocWwgQVBJ66W8IOychO2VnCDstIjquLAg7ISk7LmYXG4vLyBJbk1lbW9yeUNhY2hl64qUIGNhY2hlIOyggOyepeydhCDsnITtlZwg7L2U65Oc7J6F64uI64ukXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgY29uc3QgY2xpZW50ID0gbmV3IEFwb2xsb0NsaWVudCh7XG4gICAgdXJpOiBcImh0dHA6Ly9iYWNrZW5kLWV4YW1wbGUuY29kZWJvb3RjYW1wLmNvLmtyL2dyYXBocWxcIixcbiAgICBjYWNoZTogbmV3IEluTWVtb3J5Q2FjaGUoKSwgLy8g7Lu07ZOo7YSw7J2YIOuplOuqqOumrOyXkCDrsLHsl5Trk5zsl5DshJwg67Cb7JWE7JioIOuNsOydtO2EsCDsnoTsi5zroZwg7KCA7J6l7ZW064aT6riwID0+IOuCmOykkeyXkCDrjZQg7J6Q7IS47Z6IIOyVjOyVhOuztOq4sFxuICB9KTtcbiAgLy8gZ3JhcGhxbCBBUEnrpbwg7JyE7ZWcIOy0iOq4sCDshKTsuZhcblxuICByZXR1cm4gKFxuICAgIDxBcG9sbG9Qcm92aWRlciBjbGllbnQ9e2NsaWVudH0+XG4gICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gICAgPC9BcG9sbG9Qcm92aWRlcj5cbiAgKTtcbn1cblxuLy/rqqjrk6Ag7Y6Y7J207KeA7J2YIOqzte2GtSDshKTsoJXrk6TsnYQg7KCV66as7ZWY64qUIOqzsyDsnoXri4jri6QuXG5cbi8vIOq4sOuzuCBfYXBwLmpzIOyLnOyekVxuLy8gLy8gaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnXG5cbi8vIGV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbi8vICAgcmV0dXJuIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz47XG4vLyB9XG4vLyDquLDrs7ggX2FwcC5qcyDsooXro4xcbiJdLCJuYW1lcyI6WyJBcG9sbG9DbGllbnQiLCJJbk1lbW9yeUNhY2hlIiwiQXBvbGxvUHJvdmlkZXIiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJjbGllbnQiLCJ1cmkiLCJjYWNoZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();