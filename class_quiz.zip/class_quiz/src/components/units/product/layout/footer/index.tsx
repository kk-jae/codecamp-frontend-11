import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 10%;
  background-color: green;
`;

export default function LayoutFooter(): JSX.Element {
  return <Wrapper>푸터 영역</Wrapper>;
}
