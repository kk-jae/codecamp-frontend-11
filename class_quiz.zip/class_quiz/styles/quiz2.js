import styled from "@emotion/styled";
//퀴즈

export const Background = styled.div``;

export const Container = styled.div`
  width: 640px;
  height: 1138px;
  background-image: url(/quiz_2/background.png);
`;

export const Header = styled.div`
  display: flex;
  flex-direction: column;
`;

export const GpsImg = styled.img`
  width: 66px;
  height: 82px;
`;

export const LogoName = styled.div``;

export const Body = styled.div``;

export const Footer = styled.div``;

export const Email = styled.div``;

export const Password = styled.div``;

export const SignUp = styled.div``;

export const FindImp = styled.div``;

export const KaKao = styled.div``;
