import styled from "@emotion/styled";
//과제
export const Error = styled.div`
  color: red;
  font-size: 13px;
`;
