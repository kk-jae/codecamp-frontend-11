import ReactPlayer from 'react-player'

export default function LibraryYoutube() {

  return (

    <ReactPlayer url='https://www.youtube.com/watch?v=aOQYFTjz25Y' playing={true} muted={true} width="800px" height="600px"/>

  );
}