import DaumPostcodeEmbed from 'react-daum-postcode';

export default function LibraryAddress () {

  return (
    <DaumPostcodeEmbed></DaumPostcodeEmbed>
  );

}