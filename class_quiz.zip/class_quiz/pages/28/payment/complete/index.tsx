export default function PaymentCompletePage() {
  return (
    <>
      <>결제가 완료되었습니다.</>
    </>
  );
}
