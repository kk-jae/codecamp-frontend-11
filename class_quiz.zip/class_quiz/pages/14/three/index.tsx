export default function ThreePage() {
  return <div>three 영역 입니다.</div>;
}
