export default function OnePage() {
  return <div>one 영역 입니다.</div>;
}
