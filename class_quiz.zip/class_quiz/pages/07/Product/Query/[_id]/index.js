// import { gql, useQuery } from "@apollo/client";
// import { useRouter } from "next/router";
import ProductQuery from "../../../../../src/components/units/product/07-writer/Fetch/ProductWrite.container";

export default function ProductQueryPatten() {
  return <ProductQuery />;
}

// 페이지를 볼 수 있는 권한을 부여할 때 해당페이지를 사용합니다.
