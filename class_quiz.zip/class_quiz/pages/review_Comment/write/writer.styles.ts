export default function CommentWriteStylePage() {}
