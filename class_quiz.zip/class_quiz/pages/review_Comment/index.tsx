import CommentListPage from "./list/list.container";
import CommentWritePage from "./write/writer.container";

export default function CommenWritePage() {
  return (
    <>
      <CommentWritePage />
      <CommentListPage />
    </>
  );
}
