// import NewProductPageContainer from "../../../../../src/components/units/product/09-writer/Create/ProductWrite.container";
import NewProductPageContainer from "../../../../src/components/units/product/09-writer/Create/ProductWrite.container";

export default function UpdateProductPage() {
  return <NewProductPageContainer isEdit={true} />;
}
