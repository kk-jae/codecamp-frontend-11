export default function Presenter(props: any): JSX.Element {
  return <div>{props.child}</div>;
}
